<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="utf-8">
   <!-- <meta http-equiv="X-UA-Compatible" content="IE=edge"> -->
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
   <style>
      :root {
         --colorPrimary: #a88944;
         --colorSecondry: #a88944;
         --colorBtn: #fff;
      }
   </style>


   <title>Prestige City</title>
    

   <link rel="icon" href="assets/img/logo/favicon.png" sizes="16x16">

   <link rel="preload" href="assets/fonts/roboto-bold-webfont.woff2" as="font" type="font/woff2" crossorigin>
   <link rel="preload" href="assets/fonts/roboto-regular-webfont.woff2" as="font" type="font/woff2" crossorigin>
   <link rel="preload" href="assets/fonts/muli-variablefont_wght-webfont.woff2" as="font" type="font/woff2" crossorigin>
   <link rel="preload" href="assets/fonts/micon.woff2" as="font" type="font/woff2" crossorigin>

   <link rel="stylesheet" type="text/css" media="screen and (max-width:800px)" href="assets/css/style-sm-1.css">
   <link rel="stylesheet" type="text/css" media="screen and (min-width:801px)" href="assets/css/style-md-1.css">
   <!-- <link rel="stylesheet" type="text/css" href="assets/css/style1.css"> -->
   <link rel="stylesheet" type="text/css" href="app.css">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
   <script src='https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.bundle.min.js'></script>
   <link href='https://use.fontawesome.com/releases/v5.7.2/css/all.css'>
   <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
   <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
   <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
   <!-- <script src="assets/js/carousel_app.js.js" defer></script>  -->

   <style>
      *,
      ::after,
      ::before {
         box-sizing: border-box;
      }

      .info-box .info-title {
         font-size: 2rem;
      }

      .svgCheck {
         fill: #a88944
      }

      .info-box {
         top: 9rem;
         width: 27vw;
      }

      .rk-btn,
      .rk-btn-2 {
         text-shadow: 0px 3px 6px #a88944;
         background-color: #a88944;
         background: linear-gradient(-45deg, #a88944, #333, #a88944, #333);
         background-size: 400% 400%;
         -webkit-animation: Gradient 3s ease infinite;
         -moz-animation: Gradient 3s ease infinite;
         animation: Gradient 3s ease infinite;
      }

      @media only screen and (max-width: 800px) {
         .main-contenter {
            margin-top: 650px;
         }

         .main-slider-img {
            height: auto;
         }

         .info-box {
            margin-top: ;
            width: 100% !important;
            background: #ffffff;
         }

         .info-box .info-title {
            font-size: 3.5rem;
         }

         .mob-center {
            text-align: center;
         }

         .nav-fill .nav-item {
            width: 50%;
         }
      }

      .animated {
         -webkit-animation-duration: 1s;
         animation-duration: 1s;
         -webkit-animation-fill-mode: both;
         animation-fill-mode: both;
      }

      .animated.infinite {
         -webkit-animation-iteration-count: infinite;
         animation-iteration-count: infinite;
      }

      .animated.infinite {
         -webkit-animation-iteration-count: infinite;
         animation-iteration-count: infinite;
      }

      @-webkit-keyframes slideInDown {
         from {
            -webkit-transform: translate3d(0, -100%, 0);
            transform: translate3d(0, -100%, 0);
            visibility: visible;
         }

         to {
            -webkit-transform: translate3d(0, 0, 0);
            transform: translate3d(0, 0, 0);
         }
      }

      @keyframes slideInDown {
         from {
            -webkit-transform: translate3d(0, -100%, 0);
            transform: translate3d(0, -100%, 0);
            visibility: visible;
         }

         to {
            -webkit-transform: translate3d(0, 0, 0);
            transform: translate3d(0, 0, 0);
         }
      }

      .slideInDown {
         -webkit-animation-name: slideInDown;
         animation-name: slideInDown;
      }

      /* */

      .highlight {
         animation: bouncein 3s infinite;
      }

      @keyframes bouncein {

         0%,
         20%,
         40%,
         60%,
         80%,
         100% {
            -webkit-animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
            animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);
         }

         0% {
            opacity: 0;
            -webkit-transform: scale3d(0.3, 0.3, 0.3);
            transform: scale3d(0.3, 0.3, 0.3);
         }

         20% {
            -webkit-transform: scale3d(1.1, 1.1, 1.1);
            transform: scale3d(1.1, 1.1, 1.1);
         }

         40% {
            -webkit-transform: scale3d(0.9, 0.9, 0.9);
            transform: scale3d(0.9, 0.9, 0.9);
         }

         60% {
            opacity: 1;
            -webkit-transform: scale3d(1.03, 1.03, 1.03);
            transform: scale3d(1.03, 1.03, 1.03);
         }

         80% {
            -webkit-transform: scale3d(0.97, 0.97, 0.97);
            transform: scale3d(0.97, 0.97, 0.97);
         }

         100% {
            opacity: 1;
            -webkit-transform: scale3d(1, 1, 1);
            transform: scale3d(1, 1, 1);
         }
      }

      /* */
      @media only screen and (max-width: 800px) {
         .main-contenter {
            margin-top: 15px !important;
         }

         .ccode {
            font-size: 12px;
         }
      }

      .ccode {
         border: none;
         position: absolute !important;
         width: 100px !important;
         z-index: 1000 !important;
         height: 30px !important;
         font-weight: bold !important;
         bottom: 5px !important;
      }


      /*carousel*/
   </style>

</head>

<body>
   <div class="row main-row" id="top">
      <div class="col-md-9 col-sm-12 main-col">
         <section class="header" id="home">
            <div class="main-nav pos-fix-main" id="main-rk-nav">
               <ul class="nav nav-fill">
                  <li class="nav-item">
                     <a class="nav-link cst-logo" href="index.php" title="Prestige City "><img src="assets/img/logo/logo.png" class="mainLogo" alt="Prestige City  Logo"></a>
                  </li>
                  <li class="nav-item main-mav-item active">
                     <a class="nav-link" href="#top" title="Prestige City  Home"><img src="assets/svg/site/home.svg" class="nav-svg-icon" alt="Prestige City  Home"></a>
                  </li>
                  <li class="nav-item main-mav-item">
                     <a class="nav-link" href="#overview" title="Prestige City  Overview"><img src="assets/svg/site/overview.svg" class="nav-svg-icon" alt="Prestige City  Overview">Overview</a>
                  </li>
                  <li class="nav-item main-mav-item">
                     <a class="nav-link" href="#costing" title="Prestige City  Prices"><img src="assets/svg/site/price.png" class="nav-svg-icon" alt="Prestige City  Costing">Price</a>
                  </li>
                  <li class="nav-item main-mav-item">
                     <a class="nav-link" href="#siteplans" title="Prestige City  Plan"><img src="assets/svg/site/site-visit.png" class="nav-svg-icon" alt="Prestige City  Plan">Site & Floor Plan</a>
                  </li>
                  <li class="nav-item main-mav-item">
                     <a class="nav-link" href="#amenities" title="Prestige City  Amenities"><img src="assets/svg/site/amenities.png" class="nav-svg-icon" alt="Prestige City  Amenities">Amenities</a>
                  </li>
                  <li class="nav-item main-mav-item">
                     <a class="nav-link" href="#location" title="Prestige City  Location"><img src="assets/svg/site/location.png" class="nav-svg-icon" alt="Prestige City  Location">Location</a>
                  </li>
                  <li class="nav-item main-mav-item">
                     <a class="nav-link" href="#sitevisit" title="Prestige City  Site Visit"><img src="assets/svg/site/video-play.png" class="nav-svg-icon" alt="Prestige City  Site Visit">Virtual Visit</a>
                  </li>
                   <li class="nav-item button main-mav-item" style="background-color: #a88944;">
                  <a class="nav-link callModelRK"
                     href="javascript:void(0)"
                     onclick="setCookie('proBro', 'OK')"
                     data-toggle="modal"
                     data-name="Brochure Download"
                     data-btn="Download Now"
                     data-form="md"
                     data-target="#rkEnqForm"
                     title="Prestige City  Download"><img src="assets/svg/site/bro-download.png" class="nav-svg-icon slideInDown animated infinite" style="animation-duration: 2s;" alt="Prestige City  Download">Brochure</a>
               </li>
                  <!-- <li class="nav-item main-mav-item">
                  <a class="nav-link callModelRK"
                     href="javascript:void(0)"
                     data-toggle="modal"
                     data-name="Mail Me Complete Details"
                     data-btn="Enquire Now"
                     data-form="lg"
                     data-target="#rkEnqForm"
                     title="Prestige City  Enqiry"><img src="assets/svg/site/mail.svg" class="nav-svg-icon" alt="Prestige City  Enqiry">Enquire</a>
               </li> -->
               </ul>
            </div>
            <div class="rk-mb-nav">
               <nav class="navbar navbar-light light-blue lighten-4 rk-mb-nav-pad">
                  <p class="rk-mb-logo-div">
                     <a class="navbar-brand ml-4" href="#">
                        <img src="assets/img/logo/logo.png" class="rk-mb-logo" alt="Prestige City  Logo">
                     </a>
                  </p>
                  <button class="navbar-toggler toggler-example mr-4 rk-nav-mb-btn" type="button" data-toggle="collapse" data-target="#navbarSupportedContent1" aria-controls="navbarSupportedContent1" aria-expanded="false" aria-label="Toggle navigation"><span class="dark-blue-text">
                        <img src="assets/svg/site/nav.svg" class="nav-svg-icon" alt="Prestige City  Menu"></span></button>
                  <div class="collapse navbar-collapse rk-coll" id="navbarSupportedContent1">
                     <ul class="navbar-nav mr-auto mx-5">
                        <!-- <li class="nav-item" data-toggle="collapse" data-target="#navbarSupportedContent1">
                        <a class="nav-link" href="#" title="Prestige City  Home"><img src="assets/svg/site/home.svg" class="nav-svg-icon" alt="Prestige City  Home"> Home</a>
                     </li> -->
                        <li class="nav-item" data-toggle="collapse" data-target="#navbarSupportedContent1">
                           <a class="nav-link" href="#overview" title="Prestige City  Overview"><img src="assets/svg/site/overview.svg" class="nav-svg-icon" alt="Prestige City  Overview">Overview</a>
                        </li>
                        <li class="nav-item" data-toggle="collapse" data-target="#navbarSupportedContent1">
                           <a class="nav-link" href="#costing" title="Prestige City  Prices"><img src="assets/svg/site/price.svg" class="nav-svg-icon" alt="Prestige City  Prices">Costing</a>
                        </li>
                        <li class="nav-item" data-toggle="collapse" data-target="#navbarSupportedContent1">
                           <a class="nav-link" href="#siteplans" title="Prestige City  Plan"><img src="assets/svg/site/plan.svg" class="nav-svg-icon" alt="Prestige City  Plan">Site & Floor Plan</a>
                        </li>
                        <li class="nav-item" data-toggle="collapse" data-target="#navbarSupportedContent1">
                           <a class="nav-link" href="#amenities" title="Prestige City  Amenities"><img src="assets/svg/site/amenities.svg" class="nav-svg-icon" alt="Prestige City  Amenities">Amenities</a>
                        </li>
                        <li class="nav-item" data-toggle="collapse" data-target="#navbarSupportedContent1">
                           <a class="nav-link" href="#gallerysection" title="Prestige City  Gallery"><img src="assets/svg/site/gallery.svg" class="nav-svg-icon" alt="Prestige City  Gallery">Gallery</a>
                        </li>
                        <li class="nav-item" data-toggle="collapse" data-target="#navbarSupportedContent1">
                           <a class="nav-link" href="#location" title="Prestige City  Location"><img src="assets/svg/site/location.png" class="nav-svg-icon" alt="Prestige City  Location">Location</a>
                        </li>
                        <li class="nav-item" data-toggle="collapse" data-target="#navbarSupportedContent1">
                           <a class="nav-link" href="#sitevisit" title="Prestige City  Site Visit"><img src="assets/svg/site/site-visit.svg" class="nav-svg-icon" alt="Prestige City  Site Visit">Virtual Visit</a>
                        </li>
                        <li class="nav-item button main-mav-item" data-toggle="collapse" data-target="#navbarSupportedContent1">
                           <a class="nav-link callModelRK" href="javascript:void(0)" onclick="setCookie('proBro', 'OK')" data-toggle="modal" data-name="Brochure Download" data-btn="Download Now" data-form="md" data-target="#rkEnqForm" title="Prestige City  Download"><img src="assets/svg/site/bro-download.svg" class="nav-svg-icon slideInDown animated infinite" style="animation-duration: 2s;" alt="Prestige City  Download">Brochure</a>
                        </li>
                        <li class="nav-item" data-toggle="collapse" data-target="#navbarSupportedContent1">
                           <a class="nav-link callModelRK" href="javascript:void(0)" data-toggle="modal" data-name="Mail Me Complete Details" data-btn="Enquire Now" data-form="lg" data-target="#rkEnqForm" title="Prestige City  Enqiry"><img src="assets/svg/site/mail.svg" class="nav-svg-icon" alt="Prestige City  Enqiry">Enquire</a>
                        </li>
                     </ul>
                  </div>
               </nav>
            </div>
         </section>
         <section class="main-view">
            <div class="row main-row">
               <div id="mainSlider" class="carousel slide main-slider pos-fixed" data-ride="carousel">
                  <ol class="carousel-indicators">
                     <li data-target="#mainSlider" data-slide-to="0" class="active"></li>
                     <li data-target="#mainSlider" data-slide-to="1" class=""></li>
                     <li data-target="#mainSlider" data-slide-to="2" class=""></li>

                  </ol>
                  <div class="carousel-inner">
                     <div class="carousel-item">
                        <img src="assets/img/gallery/Prestige City -slider1.jpg" class="d-none d-md-block main-slider-img imgpren w-100" height="auto" alt="Prestige City  Image 1" srcset="">
                        <img src="assets/img/gallery/Prestige City -slider1.jpg" class="d-block d-md-none main-slider-img imgpren w-100" height="auto" alt="Prestige City  Image 1" srcset="">

                     </div>
                     <div class="carousel-item">
                        <img src="assets/img/gallery/Prestige City -slider4.jpg" class="d-none d-md-block main-slider-img imgpren w-100" height="auto" alt="Prestige City  Image 1" srcset="">
                        <img src="assets/img/gallery/Prestige City -slider4.jpg" class="d-block d-md-none main-slider-img imgpren w-100" height="auto" alt="Prestige City  Image 1" srcset="">
                     </div>
                     <div class="carousel-item">
                        <img src="assets/img/gallery/Prestige City -slider6.jpg" class="d-none d-md-block main-slider-img imgpren w-100" height="auto" alt="Prestige City  Image 1" srcset="">
                        <img src="assets/img/gallery/Prestige City -slider6.jpg" class="d-block d-md-none main-slider-img imgpren w-100" height="auto" alt="Prestige City  Image 1" srcset="">
                     </div>

                  </div>
               </div>
               <style>
                  @media (max-width:768px) {
                     .pro-status {
                        background: #a88944 !important;
                        display: block;
                        padding: 3px;
                        color: #fff;
                        font-size: 16px;
                        text-transform: uppercase;
                        text-shadow: 0 1px 2px #333;
                        text-align: center;
                     }
                  }
               </style>
               <div class="info-box">
                  <div class="pro-status" data-toggle="modal" data-name="Enquire Now" data-btn="Send Now" data-form="lg" data-target="#rkEnqForm">
                     New Launch
                  </div>

                  <div class="row main-row" style="margin-top: 34px;">
                     <div class="col-md-12 mb-0 cst-bg text-center" style=" padding:4px 0">
                        <span class="pro-title">Prestige City </span>
                        <span class="info-sub-title" style="font-size: 16px;"><span class="head head-place" style="display: block; text-align: center;"> At Off Sarjapur Road, Bangalore<br></span><span style="font-weight: 400; text-align: center;">By Prestige Group</span></span>

                     </div>
                     <div class="col-md-12 mb-0 cst-bg1 text-center" style="padding:4px 0">
                        <ul class="pro-spec">
                           <li><span class="list-icon" style="color: #a88944;">▸</span> <span class="heading">Total Apartments -</li>
                           <!-- <li><span class="list-icon">▸</span> <span class="heading">Total Acres : 7.3 Acres</li> -->
                           <li><span class="list-icon" style="color: #a88944;">▸</span> <span class="heading">Eden Park : 2200 Appx</li>
                           <li><span class="list-icon">▸</span> <span class="heading">Avalon Park : 1000 Appx</li>

                        </ul>
                        <!-- <span class="head" style="display: block; font-size:16px; "></span> -->
                     </div>

                     <span class="d-block mt-1 mb-1" style="font-size: 15px; width: 100%; background: transparent;font-weight: bold; text-align: center;color: #fff; font-weight:bold;" data-toggle="modal" data-name="Enquire Now" data-btn="Send Now" data-form="lg" data-target="#rkEnqForm">
                        <!-- <span style=" color: #fff;display: block; background-color: #a88944; background: linear-gradient(-45deg, #a88944,#a88944,#a88944,#a88944); background-size: 400% 400%; -webkit-animation: Gradient 3s ease infinite; -moz-animation: Gradient 3s ease infinite; animation: Gradient 3s ease infinite; font-size:15px; padding: 5px;">Life Of Goa Now In Virar</span> -->
                        <span style="background: linear-gradient(-45deg, #a88944, #a88944,#a88944,#a88944); display: block; padding: 15px; ">
                           <span class="highlight" style="animation-duration: 3s;display: block;padding: 2px;font-size: 14px!important; text-align: center;color: white; border: 2px solid #fff; border-style: dashed; font-weight:bold">
                           MOST AWAITED LAUNCH <br>
                           Avalon & Eden Park - Luxurious Apartments! <br>
                           Aspen Greens - Exclusive VIllas! 
                           </span>
                        </span>
                     </span>
                     <!-- <span class="d-block mt-1 mb-1" style="font-size: 15px; width: 100%; background: transparent;font-weight: bold; text-align: center;color: #fff; ">
                     <span style="  color: #fff;display: block; background-color: #a88944; background: linear-gradient(-45deg, #a88944,#a88944,#a88944,#a88944); background-size: 400% 400%; -webkit-animation: Gradient 3s ease infinite; -moz-animation: Gradient 3s ease infinite; animation: Gradient 3s ease infinite; font-size:15px; padding: 5px;"></span> 
                  </span> -->
                     <!-- <span class="d-block mt-1 mb-1" style="font-size: 15px; width: 100%; background: transparent;font-weight: bold; text-align: center;color: #fff; " data-toggle="modal" data-name="Enquire Now" data-btn="Send Now" data-form="lg" data-target="#rkEnqForm">
                        <span style="  color: #fff;display: block; background-color: #a88944; background: linear-gradient(-45deg, #a88944,#a88944,#a88944,#a88944); background-size: 400% 400%; -webkit-animation: Gradient 3s ease infinite; -moz-animation: Gradient 3s ease infinite; animation: Gradient 3s ease infinite; font-size:15px; padding: 5px;">New Tower Launch - Palm Springs Additional Exclusive Offers Excellent Connectivity</span>
                     </span> -->
                     <div class="col-md-12 mb-3 text-center" style="margin-bottom: 0%!important; padding:0%">
                        <span class="head cst-clr" style="display: block;   font-weight:400">Premium 1, 2, 3 & 4 BHK Starts</span>
                     </div>
                     
                     <div class="row main-row" align='center' style="width: 100%; padding:0%">
                        <div class="col-md-12" style="padding:0%">
                           <span class="head cst-clr" style="display: block; font-size: 2.2rem; font-weight:700">₹ 41.49 Lacs*<small style="font-weight: 400;">All Incl.</small></span><br>
                           <span class="head cst-clr" style="display: block;   font-weight:400">Exclusive Villas Start</span>
                           <span class="head cst-clr" style="display: block; font-size: 2.2rem; font-weight:700">₹ 2.99 Cr* <small style="font-weight: 400;">Onwards</small></span>
                           <p class="mb-center cst-algn" style="margin-top: 5px;">
                              <button class="btn micro-form-btn effetGradient effectScale effetMoveGradient py-2 px-5 text-white callModelRK" style="animation: Gradient 3s ease infinite, rocking 2s infinite; animation-delay: 2s;" data-toggle="modal" data-name="Enquire Now" data-btn="Send Now" data-form="lg" data-target="#rkEnqForm">Enquire Now</button>
                              <img src="assets/img/pdf.png" data-toggle="modal" data-name="Brochure Download" data-btn="Download Now" data-form="md" data-target="#rkEnqForm" class="d-none d-md-block highlight" style="position: absolute; bottom:0rem; width: 30px; right: 2rem; cursor:pointer"><br><br>
                              <span style="" class="pro-rera"><span class="pro-rera-title">RERA No</span> : PRM/KA/RERA/1251/308/PR/210928/004316</span>
                           </p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="d-block d-md-none mob-form">
                  <h4 class="form-heading font-weight-bold">Pre-Register here for Best Offers</h4>
                  <div class="d-block d-md-none" align='center'>

                     <!-- <h4 class="enq-heading font-weight-bold">Pre-Register here for Best Offers</h4> -->

                     <form method="POST" action="mail.php">
                        <input type="hidden" name="captcha">
                        <input type="hidden" name="pname" value="Prestige City ">
                        <input type="hidden" name="form_type" value="Call Back Now">
                        <div class="col-md-12 mt-3 mb-3">
                           <input type="text" class="form-control rk-input" id="validationCustom01" name="name" placeholder="Name" autocomplete="off" required>
                        </div>
                        <div class="col-md-12 mt-3 mb-4">
                           <!--<select name="countrycode" class="form-control ccode" style="cursor:pointer" required="required">-->
                           <!--   <option disabled="disabled" value="">Country Code</option>-->
                           <!--   <option data-countryCode="IN" name="countrycode" value="91" selected="selected">India (+91)</option>-->
                           <!--   <option data-countryCode="GB" name="countrycode" value="44">UK (+44)</option>-->
                           <!--   <option data-countryCode="US" name="countrycode" value="1">USA (+1)</option>-->
                           <!--   <optgroup label="Other countries">-->
                           <!--      <option data-countryCode="DZ" name="countrycode" value="213">Algeria (+213)</option>-->
                           <!--      <option data-countryCode="AD" name="countrycode" value="376">Andorra (+376)</option>-->
                           <!--      <option data-countryCode="AO" name="countrycode" value="244">Angola (+244)</option>-->
                           <!--      <option data-countryCode="AI" name="countrycode" value="1264">Anguilla (+1264)</option>-->
                           <!--      <option data-countryCode="AG" name="countrycode" value="1268">Antigua &amp; Barbuda (+1268)</option>-->
                           <!--      <option data-countryCode="AR" name="countrycode" value="54">Argentina (+54)</option>-->
                           <!--      <option data-countryCode="AM" name="countrycode" value="374">Armenia (+374)</option>-->
                           <!--      <option data-countryCode="AW" name="countrycode" value="297">Aruba (+297)</option>-->
                           <!--      <option data-countryCode="AU" name="countrycode" value="61">Australia (+61)</option>-->
                           <!--      <option data-countryCode="AT" value="43">Austria (+43)</option>-->
                           <!--      <option data-countryCode="AZ" name="countrycode" value="994">Azerbaijan (+994)</option>-->
                           <!--      <option data-countryCode="BS" name="countrycode" value="1242">Bahamas (+1242)</option>-->
                           <!--      <option data-countryCode="BH" name="countrycode" value="973">Bahrain (+973)</option>-->
                           <!--      <option data-countryCode="BD" name="countrycode" value="880">Bangladesh (+880)</option>-->
                           <!--      <option data-countryCode="BB" name="countrycode" value="1246">Barbados (+1246)</option>-->
                           <!--      <option data-countryCode="BY" name="countrycode" value="375">Belarus (+375)</option>-->
                           <!--      <option data-countryCode="BE" name="countrycode" value="32">Belgium (+32)</option>-->
                           <!--      <option data-countryCode="BZ" name="countrycode" value="501">Belize (+501)</option>-->
                           <!--      <option data-countryCode="BJ" name="countrycode" value="229">Benin (+229)</option>-->
                           <!--      <option data-countryCode="BM" name="countrycode" value="1441">Bermuda (+1441)</option>-->
                           <!--      <option data-countryCode="BT" name="countrycode" value="975">Bhutan (+975)</option>-->
                           <!--      <option data-countryCode="BO" name="countrycode" value="591">Bolivia (+591)</option>-->
                           <!--      <option data-countryCode="BA" name="countrycode" value="387">Bosnia Herzegovina (+387)</option>-->
                           <!--      <option data-countryCode="BW" name="countrycode" value="267">Botswana (+267)</option>-->
                           <!--      <option data-countryCode="BR" name="countrycode" value="55">Brazil (+55)</option>-->
                           <!--      <option data-countryCode="BN" name="countrycode" value="673">Brunei (+673)</option>-->
                           <!--      <option data-countryCode="BG" name="countrycode" value="359">Bulgaria (+359)</option>-->
                           <!--      <option data-countryCode="BF" name="countrycode" value="226">Burkina Faso (+226)</option>-->
                           <!--      <option data-countryCode="BI" name="countrycode" value="257">Burundi (+257)</option>-->
                           <!--      <option data-countryCode="KH" name="countrycode" value="855">Cambodia (+855)</option>-->
                           <!--      <option data-countryCode="CM" name="countrycode" value="237">Cameroon (+237)</option>-->
                           <!--      <option data-countryCode="CA" name="countrycode" value="1">Canada (+1)</option>-->
                           <!--      <option data-countryCode="CV" name="countrycode" value="238">Cape Verde Islands (+238)</option>-->
                           <!--      <option data-countryCode="KY" name="countrycode" value="1345">Cayman Islands (+1345)</option>-->
                           <!--      <option data-countryCode="CF" name="countrycode" value="236">Central African Republic (+236)</option>-->
                           <!--      <option data-countryCode="CL" name="countrycode" value="56">Chile (+56)</option>-->
                           <!--      <option data-countryCode="CN" name="countrycode" value="86">China (+86)</option>-->
                           <!--      <option data-countryCode="CO" name="countrycode" value="57">Colombia (+57)</option>-->
                           <!--      <option data-countryCode="KM" name="countrycode" value="269">Comoros (+269)</option>-->
                           <!--      <option data-countryCode="CG" name="countrycode" value="242">Congo (+242)</option>-->
                           <!--      <option data-countryCode="CK" name="countrycode" value="682">Cook Islands (+682)</option>-->
                           <!--      <option data-countryCode="CR" name="countrycode" value="506">Costa Rica (+506)</option>-->
                           <!--      <option data-countryCode="HR" name="countrycode" value="385">Croatia (+385)</option>-->
                           <!--      <option data-countryCode="CU" name="countrycode" value="53">Cuba (+53)</option>-->
                           <!--      <option data-countryCode="CY" name="countrycode" value="90392">Cyprus North (+90392)</option>-->
                           <!--      <option data-countryCode="CY" name="countrycode" value="357">Cyprus South (+357)</option>-->
                           <!--      <option data-countryCode="CZ" name="countrycode" value="42">Czech Republic (+42)</option>-->
                           <!--      <option data-countryCode="DK" name="countrycode" value="45">Denmark (+45)</option>-->
                           <!--      <option data-countryCode="DJ" name="countrycode" value="253">Djibouti (+253)</option>-->
                           <!--      <option data-countryCode="DM" name="countrycode" value="1809">Dominica (+1809)</option>-->
                           <!--      <option data-countryCode="DO" name="countrycode" value="1809">Dominican Republic (+1809)</option>-->
                           <!--      <option data-countryCode="EC" name="countrycode" value="593">Ecuador (+593)</option>-->
                           <!--      <option data-countryCode="EG" name="countrycode" value="20">Egypt (+20)</option>-->
                           <!--      <option data-countryCode="SV" name="countrycode" value="503">El Salvador (+503)</option>-->
                           <!--      <option data-countryCode="GQ" name="countrycode" value="240">Equatorial Guinea (+240)</option>-->
                           <!--      <option data-countryCode="ER" name="countrycode" value="291">Eritrea (+291)</option>-->
                           <!--      <option data-countryCode="EE" name="countrycode" value="372">Estonia (+372)</option>-->
                           <!--      <option data-countryCode="ET" name="countrycode" value="251">Ethiopia (+251)</option>-->
                           <!--      <option data-countryCode="FK" name="countrycode" value="500">Falkland Islands (+500)</option>-->
                           <!--      <option data-countryCode="FO" name="countrycode" value="298">Faroe Islands (+298)</option>-->
                           <!--      <option data-countryCode="FJ" name="countrycode" value="679">Fiji (+679)</option>-->
                           <!--      <option data-countryCode="FI" name="countrycode" value="358">Finland (+358)</option>-->
                           <!--      <option data-countryCode="FR" name="countrycode" value="33">France (+33)</option>-->
                           <!--      <option data-countryCode="GF" name="countrycode" value="594">French Guiana (+594)</option>-->
                           <!--      <option data-countryCode="PF" name="countrycode" value="689">French Polynesia (+689)</option>-->
                           <!--      <option data-countryCode="GA" name="countrycode" value="241">Gabon (+241)</option>-->
                           <!--      <option data-countryCode="GM" name="countrycode" value="220">Gambia (+220)</option>-->
                           <!--      <option data-countryCode="GE" name="countrycode" value="7880">Georgia (+7880)</option>-->
                           <!--      <option data-countryCode="DE" name="countrycode" value="49">Germany (+49)</option>-->
                           <!--      <option data-countryCode="GH" name="countrycode" value="233">Ghana (+233)</option>-->
                           <!--      <option data-countryCode="GI" name="countrycode" value="350">Gibraltar (+350)</option>-->
                           <!--      <option data-countryCode="GR" name="countrycode" value="30">Greece (+30)</option>-->
                           <!--      <option data-countryCode="GL" name="countrycode" value="299">Greenland (+299)</option>-->
                           <!--      <option data-countryCode="GD" name="countrycode" value="1473">Grenada (+1473)</option>-->
                           <!--      <option data-countryCode="GP" name="countrycode" value="590">Guadeloupe (+590)</option>-->
                           <!--      <option data-countryCode="GU" name="countrycode" value="671">Guam (+671)</option>-->
                           <!--      <option data-countryCode="GT" name="countrycode" value="502">Guatemala (+502)</option>-->
                           <!--      <option data-countryCode="GN" name="countrycode" value="224">Guinea (+224)</option>-->
                           <!--      <option data-countryCode="GW" name="countrycode" value="245">Guinea - Bissau (+245)</option>-->
                           <!--      <option data-countryCode="GY" name="countrycode" value="592">Guyana (+592)</option>-->
                           <!--      <option data-countryCode="HT" name="countrycode" value="509">Haiti (+509)</option>-->
                           <!--      <option data-countryCode="HN" name="countrycode" value="504">Honduras (+504)</option>-->
                           <!--      <option data-countryCode="HK" name="countrycode" value="852">Hong Kong (+852)</option>-->
                           <!--      <option data-countryCode="HU" name="countrycode" value="36">Hungary (+36)</option>-->
                           <!--      <option data-countryCode="IS" name="countrycode" value="354">Iceland (+354)</option>-->
                           <!--      <option data-countryCode="ID" name="countrycode" value="62">Indonesia (+62)</option>-->
                           <!--      <option data-countryCode="IR" name="countrycode" value="98">Iran (+98)</option>-->
                           <!--      <option data-countryCode="IQ" name="countrycode" value="964">Iraq (+964)</option>-->
                           <!--      <option data-countryCode="IE" name="countrycode" value="353">Ireland (+353)</option>-->
                           <!--      <option data-countryCode="IL" name="countrycode" value="972">Israel (+972)</option>-->
                           <!--      <option data-countryCode="IT" name="countrycode" value="39">Italy (+39)</option>-->
                           <!--      <option data-countryCode="JM" name="countrycode" value="1876">Jamaica (+1876)</option>-->
                           <!--      <option data-countryCode="JP" name="countrycode" value="81">Japan (+81)</option>-->
                           <!--      <option data-countryCode="JO" name="countrycode" value="962">Jordan (+962)</option>-->
                           <!--      <option data-countryCode="KZ" name="countrycode" value="7">Kazakhstan (+7)</option>-->
                           <!--      <option data-countryCode="KE" name="countrycode" value="254">Kenya (+254)</option>-->
                           <!--      <option data-countryCode="KI" name="countrycode" value="686">Kiribati (+686)</option>-->
                           <!--      <option data-countryCode="KP" name="countrycode" value="850">Korea North (+850)</option>-->
                           <!--      <option data-countryCode="KR" name="countrycode" value="82">Korea South (+82)</option>-->
                           <!--      <option data-countryCode="KW" name="countrycode" value="965">Kuwait (+965)</option>-->
                           <!--      <option data-countryCode="KG" name="countrycode" value="996">Kyrgyzstan (+996)</option>-->
                           <!--      <option data-countryCode="LA" name="countrycode" value="856">Laos (+856)</option>-->
                           <!--      <option data-countryCode="LV" name="countrycode" value="371">Latvia (+371)</option>-->
                           <!--      <option data-countryCode="LB" name="countrycode" value="961">Lebanon (+961)</option>-->
                           <!--      <option data-countryCode="LS" name="countrycode" value="266">Lesotho (+266)</option>-->
                           <!--      <option data-countryCode="LR" name="countrycode" value="231">Liberia (+231)</option>-->
                           <!--      <option data-countryCode="LY" name="countrycode" value="218">Libya (+218)</option>-->
                           <!--      <option data-countryCode="LI" name="countrycode" value="417">Liechtenstein (+417)</option>-->
                           <!--      <option data-countryCode="LT" name="countrycode" value="370">Lithuania (+370)</option>-->
                           <!--      <option data-countryCode="LU" name="countrycode" value="352">Luxembourg (+352)</option>-->
                           <!--      <option data-countryCode="MO" name="countrycode" value="853">Macao (+853)</option>-->
                           <!--      <option data-countryCode="MK" name="countrycode" value="389">Macedonia (+389)</option>-->
                           <!--      <option data-countryCode="MG" name="countrycode" value="261">Madagascar (+261)</option>-->
                           <!--      <option data-countryCode="MW" name="countrycode" value="265">Malawi (+265)</option>-->
                           <!--      <option data-countryCode="MY" name="countrycode" value="60">Malaysia (+60)</option>-->
                           <!--      <option data-countryCode="MV" name="countrycode" value="960">Maldives (+960)</option>-->
                           <!--      <option data-countryCode="ML" name="countrycode" value="223">Mali (+223)</option>-->
                           <!--      <option data-countryCode="MT" name="countrycode" value="356">Malta (+356)</option>-->
                           <!--      <option data-countryCode="MH" name="countrycode" value="692">Marshall Islands (+692)</option>-->
                           <!--      <option data-countryCode="MQ" name="countrycode" value="596">Martinique (+596)</option>-->
                           <!--      <option data-countryCode="MR" name="countrycode" value="222">Mauritania (+222)</option>-->
                           <!--      <option data-countryCode="YT" name="countrycode" value="269">Mayotte (+269)</option>-->
                           <!--      <option data-countryCode="MX" name="countrycode" value="52">Mexico (+52)</option>-->
                           <!--      <option data-countryCode="FM" name="countrycode" value="691">Micronesia (+691)</option>-->
                           <!--      <option data-countryCode="MD" name="countrycode" value="373">Moldova (+373)</option>-->
                           <!--      <option data-countryCode="MC" name="countrycode" value="377">Monaco (+377)</option>-->
                           <!--      <option data-countryCode="MN" name="countrycode" value="976">Mongolia (+976)</option>-->
                           <!--      <option data-countryCode="MS" name="countrycode" value="1664">Montserrat (+1664)</option>-->
                           <!--      <option data-countryCode="MA" name="countrycode" value="212">Morocco (+212)</option>-->
                           <!--      <option data-countryCode="MZ" name="countrycode" value="258">Mozambique (+258)</option>-->
                           <!--      <option data-countryCode="MN" name="countrycode" value="95">Myanmar (+95)</option>-->
                           <!--      <option data-countryCode="NA" name="countrycode" value="264">Namibia (+264)</option>-->
                           <!--      <option data-countryCode="NR" name="countrycode" value="674">Nauru (+674)</option>-->
                           <!--      <option data-countryCode="NP" name="countrycode" value="977">Nepal (+977)</option>-->
                           <!--      <option data-countryCode="NL" name="countrycode" value="31">Netherlands (+31)</option>-->
                           <!--      <option data-countryCode="NC" name="countrycode" value="687">New Caledonia (+687)</option>-->
                           <!--      <option data-countryCode="NZ" name="countrycode" value="64">New Zealand (+64)</option>-->
                           <!--      <option data-countryCode="NI" name="countrycode" value="505">Nicaragua (+505)</option>-->
                           <!--      <option data-countryCode="NE" name="countrycode" value="227">Niger (+227)</option>-->
                           <!--      <option data-countryCode="NG" name="countrycode" value="234">Nigeria (+234)</option>-->
                           <!--      <option data-countryCode="NU" name="countrycode" value="683">Niue (+683)</option>-->
                           <!--      <option data-countryCode="NF" name="countrycode" value="672">Norfolk Islands (+672)</option>-->
                           <!--      <option data-countryCode="NP" name="countrycode" value="670">Northern Marianas (+670)</option>-->
                           <!--      <option data-countryCode="NO" name="countrycode" value="47">Norway (+47)</option>-->
                           <!--      <option data-countryCode="OM" name="countrycode" value="968">Oman (+968)</option>-->
                           <!--      <option data-countryCode="PW" name="countrycode" value="680">Palau (+680)</option>-->
                           <!--      <option data-countryCode="PA" name="countrycode" value="507">Panama (+507)</option>-->
                           <!--      <option data-countryCode="PG" name="countrycode" value="675">Papua New Guinea (+675)</option>-->
                           <!--      <option data-countryCode="PY" name="countrycode" value="595">Paraguay (+595)</option>-->
                           <!--      <option data-countryCode="PE" name="countrycode" value="51">Peru (+51)</option>-->
                           <!--      <option data-countryCode="PH" name="countrycode" value="63">Philippines (+63)</option>-->
                           <!--      <option data-countryCode="PL" name="countrycode" value="48">Poland (+48)</option>-->
                           <!--      <option data-countryCode="PT" name="countrycode" value="351">Portugal (+351)</option>-->
                           <!--      <option data-countryCode="PR" name="countrycode" value="1787">Puerto Rico (+1787)</option>-->
                           <!--      <option data-countryCode="QA" name="countrycode" value="974">Qatar (+974)</option>-->
                           <!--      <option data-countryCode="RE" name="countrycode" value="262">Reunion (+262)</option>-->
                           <!--      <option data-countryCode="RO" name="countrycode" value="40">Romania (+40)</option>-->
                           <!--      <option data-countryCode="RU" name="countrycode" value="7">Russia (+7)</option>-->
                           <!--      <option data-countryCode="RW" name="countrycode" value="250">Rwanda (+250)</option>-->
                           <!--      <option data-countryCode="SM" name="countrycode" value="378">San Marino (+378)</option>-->
                           <!--      <option data-countryCode="ST" name="countrycode" value="239">Sao Tome &amp; Principe (+239)</option>-->
                           <!--      <option data-countryCode="SA" name="countrycode" value="966">Saudi Arabia (+966)</option>-->
                           <!--      <option data-countryCode="SN" name="countrycode" value="221">Senegal (+221)</option>-->
                           <!--      <option data-countryCode="CS" name="countrycode" value="381">Serbia (+381)</option>-->
                           <!--      <option data-countryCode="SC" name="countrycode" value="248">Seychelles (+248)</option>-->
                           <!--      <option data-countryCode="SL" name="countrycode" value="232">Sierra Leone (+232)</option>-->
                           <!--      <option data-countryCode="SG" name="countrycode" value="65">Singapore (+65)</option>-->
                           <!--      <option data-countryCode="SK" name="countrycode" value="421">Slovak Republic (+421)</option>-->
                           <!--      <option data-countryCode="SI" name="countrycode" value="386">Slovenia (+386)</option>-->
                           <!--      <option data-countryCode="SB" name="countrycode" value="677">Solomon Islands (+677)</option>-->
                           <!--      <option data-countryCode="SO" name="countrycode" value="252">Somalia (+252)</option>-->
                           <!--      <option data-countryCode="ZA" name="countrycode" value="27">South Africa (+27)</option>-->
                           <!--      <option data-countryCode="ES" name="countrycode" value="34">Spain (+34)</option>-->
                           <!--      <option data-countryCode="LK" name="countrycode" value="94">Sri Lanka (+94)</option>-->
                           <!--      <option data-countryCode="SH" name="countrycode" value="290">St. Helena (+290)</option>-->
                           <!--      <option data-countryCode="KN" name="countrycode" value="1869">St. Kitts (+1869)</option>-->
                           <!--      <option data-countryCode="SC" name="countrycode" value="1758">St. Lucia (+1758)</option>-->
                           <!--      <option data-countryCode="SD" name="countrycode" value="249">Sudan (+249)</option>-->
                           <!--      <option data-countryCode="SR" name="countrycode" value="597">Suriname (+597)</option>-->
                           <!--      <option data-countryCode="SZ" name="countrycode" value="268">Swaziland (+268)</option>-->
                           <!--      <option data-countryCode="SE" name="countrycode" value="46">Sweden (+46)</option>-->
                           <!--      <option data-countryCode="CH" name="countrycode" value="41">Switzerland (+41)</option>-->
                           <!--      <option data-countryCode="SI" name="countrycode" value="963">Syria (+963)</option>-->
                           <!--      <option data-countryCode="TW" name="countrycode" value="886">Taiwan (+886)</option>-->
                           <!--      <option data-countryCode="TJ" name="countrycode" value="7">Tajikstan (+7)</option>-->
                           <!--      <option data-countryCode="TH" name="countrycode" value="66">Thailand (+66)</option>-->
                           <!--      <option data-countryCode="TG" name="countrycode" value="228">Togo (+228)</option>-->
                           <!--      <option data-countryCode="TO" name="countrycode" value="676">Tonga (+676)</option>-->
                           <!--      <option data-countryCode="TT" name="countrycode" value="1868">Trinidad &amp; Tobago (+1868)</option>-->
                           <!--      <option data-countryCode="TN" name="countrycode" value="216">Tunisia (+216)</option>-->
                           <!--      <option data-countryCode="TR" name="countrycode" value="90">Turkey (+90)</option>-->
                           <!--      <option data-countryCode="TM" name="countrycode" value="7">Turkmenistan (+7)</option>-->
                           <!--      <option data-countryCode="TM" name="countrycode" value="993">Turkmenistan (+993)</option>-->
                           <!--      <option data-countryCode="TC" name="countrycode" value="1649">Turks &amp; Caicos Islands (+1649)</option>-->
                           <!--      <option data-countryCode="TV" name="countrycode" value="688">Tuvalu (+688)</option>-->
                           <!--      <option data-countryCode="UG" name="countrycode" value="256">Uganda (+256)</option>-->
                                 <!-- <option data-countryCode="GB" value="44">UK (+44)</option> -->
                           <!--      <option data-countryCode="UA" name="countrycode" value="380">Ukraine (+380)</option>-->
                           <!--      <option data-countryCode="AE" name="countrycode" value="971">United Arab Emirates (+971)</option>-->
                           <!--      <option data-countryCode="UY" name="countrycode" value="598">Uruguay (+598)</option>-->
                                 <!-- <option data-countryCode="US" value="1">USA (+1)</option> -->
                           <!--      <option data-countryCode="UZ" name="countrycode" value="7">Uzbekistan (+7)</option>-->
                           <!--      <option data-countryCode="VU" name="countrycode" value="678">Vanuatu (+678)</option>-->
                           <!--      <option data-countryCode="VA" name="countrycode" value="379">Vatican City (+379)</option>-->
                           <!--      <option data-countryCode="VE" name="countrycode" value="58">Venezuela (+58)</option>-->
                           <!--      <option data-countryCode="VN" name="countrycode" value="84">Vietnam (+84)</option>-->
                           <!--      <option data-countryCode="VG" name="countrycode" value="84">Virgin Islands - British (+1284)</option>-->
                           <!--      <option data-countryCode="VI" name="countrycode" value="84">Virgin Islands - US (+1340)</option>-->
                           <!--      <option data-countryCode="WF" name="countrycode" value="681">Wallis &amp; Futuna (+681)</option>-->
                           <!--      <option data-countryCode="YE" name="countrycode" value="969">Yemen (North)(+969)</option>-->
                           <!--      <option data-countryCode="YE" name="countrycode" value="967">Yemen (South)(+967)</option>-->
                           <!--      <option data-countryCode="ZM" name="countrycode" value="260">Zambia (+260)</option>-->
                           <!--      <option data-countryCode="ZW" name="countrycode" value="263">Zimbabwe (+263)</option>-->
                           <!--   </optgroup>-->
                           <!--</select>-->
                           <input type="text" class="form-control rk-input" id="validationCustom03" name="phone" placeholder="Mobile No" autocomplete="off" required style="padding-left:">
                        </div>
                        <div class="col-md-12 mt-3 mb-3">
                           <input type="email" class="form-control rk-input" id="validationCustom02" name="email" placeholder="Email" autocomplete="off" required="">
                        </div>
                        <button class="btn rk-btn py-2 px-5" style="animation: Gradient 3s ease infinite, rocking 2s infinite; animation-delay: 2s;" name="submit" type="submit">Pre-Register Now</button>
                     </form>
                     <br>
                  </div>
               </div>
               <div class="row main-row-rk">
                  <div class="col-lg-12 col-md-12 col-sm-12 main-background main-contenter">

                     <section class="overview">
                        <span class="rk-section" id="overview"></span>
                        <div class="card rk-card fst-div">
                           <div class="card-body">
                              <span class="rk-card-header rk-sm-none">Overview</span>
                              <div class="rk-card-container">
                                 <span class="rk-card-main-heading" style="text-align: left; margin-bottom:10px">Prestige City  - At Off Sarjapur Road, Bangalore</span>
                                 <p style="color:#333; font-size:16px">The Prestige City is a futuristic residential project by the Prestige Group off Sarjapur Road in Bangalore. People who wish to buy a home in Bangalore can now relish their time to come, buy an apartment at The Prestige City of the Prestige Group in Bangalore. It is solely an upcoming project, and many buyers are on the lookout for purchasing a dream home. It also mentions the availability of many payment plans that would be construction linked.</p>

                                 <center class="d-block d-md-none"><button class="btn sectio-bro-btn callModelRK" style="animation: Gradient 3s ease infinite, rocking 2s infinite; animation-delay: 2s; background-color: #a88944!important; color: #ffffff!important;" data-toggle="modal" data-name="Brochure Download" data-btn="Download Now" data-form="md" data-target="#rkEnqForm">
                                       <img src="assets/svg/site/bro-download.svg" class="nav-svg-icon slideInDown animated infinite" style="animation-duration: 2s;" alt="Prestige City  Download">&nbsp;&nbsp;Download Brochure <i class="fas fa-download"></i>
                                    </button></center>
                                 <button style="animation: Gradient 3s ease infinite, rocking 2s infinite; animation-delay: 2s; background-color: #a88944!important; color: #ffffff!important;" class="btn sectio-bro-btn callModelRK d-none d-md-block" data-toggle="modal" data-name="Brochure Download" data-btn="Download Now" data-form="md" data-target="#rkEnqForm">
                                    <img src="assets/svg/site/bro-download.svg" class="nav-svg-icon slideInDown animated infinite" style="animation-duration: 2s; " alt="Prestige City  Download">&nbsp;&nbsp;Download Brochure <i class="fas fa-download"></i>
                                 </button>
                                 <!-- <hr>
                              <img src="assets/img/highlights.JPG" width="100%" data-toggle="modal"
                              data-name="Enquire Now"
                              data-btn="Send Now"
                              data-form="lg"
                              data-target="#rkEnqForm" alt=""> -->
                                 <!-- <iframe width="100%" height="400" src="https://www.youtube.com/embed/2Ouu6MZTT9o" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe> -->

                                 <!-- <div id="overviewRKSlider" class="carousel slide rk-slider" data-ride="carousel">
                                 <div class="carousel-inner">
                                    <div class="carousel-item">
                                       <img class="w-100 rk-slider-img imgpren lazy" src="assets/svg/site/loader.svg" data-src="assets/img/tree-club.jpg"
                                          srcset="" >
                                    </div>
                                 </div>
                                 <a class="carousel-control-prev" href="#overviewRKSlider" role="button" data-slide="prev">
                                 <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                 <span class="sr-only">Previous</span>
                                 </a>
                                 <a class="carousel-control-next" href="#overviewRKSlider" role="button" data-slide="next">
                                 <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                 <span class="sr-only">Next</span>
                                 </a>
                              </div> -->
                                 <!--  <center><h2>Project Highlights:</h2> <p style="font-size: 16px;font-weight: bold;text-align: center;">A Gated Branded Residential development with 5 Tier Greens*:</p></center>
                              <div class="row"> <div class="col-sm-6"> <ul class="list-group pro-highlights"> <li class="list-group-item" style="color:#000;text-shadow:none;"> </li> </ul> </div> </div> -->

                              </div>
                           </div>
                        </div>
                     </section>
                     <br><br>
                     <section class="location" id="pricing">
                        <br>
                        <span class="rk-section" id="costing"></span>
                        <div class="card rk-card">
                           <div class="card-body">
                              <span class="rk-card-header rk-sm-none">Price</span>
                              <!-- <h2 class="color-primary rk-md-none">Price</h2> -->
                              <span class="d-md-none rk-card-main-heading" style="text-align: left; margin-bottom:10px">Pricing</span>
                              <div class="rk-card-container">
                                 <div class="row">
                                    <div class="col-md-8 col-12">
                                       <table class="table table-striped table-borderless border micro-price-table table-pricing" style="border-collapse: collapse; width:100%; text-align:center; color: #333333!important;">
                                          <thead>
                                             <tr>
                                                <th class="border" style="text-align:center;">Type</th>
                                                <th class="border" style="text-align:center;">RERA Carpet</th>
                                                <th class="border" style="text-align:center;">Price</th>
                                             </tr>
                                          </thead>
                                          <!-- <tr >
                                           <td colspan='3' class='highlight' style='animation-duration: 3s; text-align: center; color: #000000; font-weight:600'>10|10|80 Flexi Scheme, Pre-Book Now, 1 BHK - ₹ 3 Lacs | 2 BHK - ₹ 5 Lac</td>
                                       </tr> -->
                                          <tr data-toggle="modal" data-name="Request Price Breakup" data-btn="Send Now" data-form="lg" data-target="#rkEnqForm" class="mobile_table">
                                             <td class="border price-type" style="text-align:center ;">1 BHK</td>
                                             <td style="border: 1px solid #dee2e6;">
                                             634 - 666 Sq.ft
                                                <!-- <button class="btn btn-primary effetGradient effectScale callModelRK" data-toggle="modal"
                                           data-name="Request Price Breakup"
                                           data-btn="Send Now"
                                           data-form="lg"
                                           data-target="#rkEnqForm">View Carpet Ares</button> -->
                                             </td>
                                             <td class="price-amt" style="border: 1px solid #dee2e6; text-align:">&#8377; 41.49 Lacs* All In+ <br>
                                                <button class="btn btn-primary effetGradient effectScale callModelRK" style="animation: Gradient 3s ease infinite, rocking 2s infinite; animation-delay: 2s;">Price Breakup</button>
                                          </tr>
                                          <tr data-toggle="modal" data-name="Request Price Breakup" data-btn="Send Now" data-form="lg" data-target="#rkEnqForm" class="mobile_table">
                                             <td class="border price-type" style="text-align: ;">2 BHK </td>
                                             <td style="border: 1px solid #dee2e6;">
                                             944 - 979 Sq.ft
                                                <!-- <button class="btn btn-primary effetGradient effectScale callModelRK" data-toggle="modal"
                                           data-name="Request Price Breakup"
                                           data-btn="Send Now"
                                           data-form="lg"
                                           data-target="#rkEnqForm">View Carpet Ares</button> -->
                                             </td>
                                             <td class="price-amt" style="border: 1px solid #dee2e6; text-align:">&#8377; 58.99 Lacs* All In+ <br>
                                                <button class="btn btn-primary effetGradient effectScale callModelRK" style="animation: Gradient 3s ease infinite, rocking 2s infinite; animation-delay: 2s;">Price Breakup</button>
                                             </td>
                                          </tr>
                                          <tr data-toggle="modal" data-name="Request Price Breakup" data-btn="Send Now" data-form="lg" data-target="#rkEnqForm" class="mobile_table">
                                             <td class="border price-type" style="text-align: ;">3 BHK</td>
                                             <td style="border: 1px solid #dee2e6;">
                                             1361 - 1657 Sq.ft
                                                <!-- <button class="btn btn-primary effetGradient effectScale callModelRK" data-toggle="modal"
                                           data-name="Request Price Breakup"
                                           data-btn="Send Now"
                                           data-form="lg"
                                           data-target="#rkEnqForm">View Carpet Ares</button> -->
                                             </td>
                                             <td class="price-amt" style="border: 1px solid #dee2e6; text-align:">&#8377; 79.9Lacs* - 1.12 Cr* All In+ <br>
                                                <button class="btn btn-primary effetGradient effectScale callModelRK" style="animation: Gradient 3s ease infinite, rocking 2s infinite; animation-delay: 2s;">Price Breakup</button>
                                             </td>

                                          </tr>
                                          <tr data-toggle="modal" data-name="Request Price Breakup" data-btn="Send Now" data-form="lg" data-target="#rkEnqForm" class="mobile_table">
                                             <td class="border price-type" style="text-align: ;">4 BHK</td>
                                             <td style="border: 1px solid #dee2e6;">
                                             2204 - 2290 Sq.ft
                                                <!-- <button class="btn btn-primary effetGradient effectScale callModelRK" data-toggle="modal"
                                           data-name="Request Price Breakup"
                                           data-btn="Send Now"
                                           data-form="lg"
                                           data-target="#rkEnqForm">View Carpet Ares</button> -->
                                             </td>
                                             <td class="price-amt" style="border: 1px solid #dee2e6; text-align:">&#8377; 1.34 - 1.39 Cr* All In+<br>
                                                <button class="btn btn-primary effetGradient effectScale callModelRK" style="animation: Gradient 3s ease infinite, rocking 2s infinite; animation-delay: 2s;">Price Breakup</button>
                                             </td>

                                          </tr>
                                          <tr data-toggle="modal" data-name="Request Price Breakup" data-btn="Send Now" data-form="lg" data-target="#rkEnqForm" class="mobile_table">
                                             <td class="border price-type" style="text-align: ;">Villas</td>
                                             <td style="border: 1px solid #dee2e6;">
                                             3344 - 3593 Sq.ft
                                                <!-- <button class="btn btn-primary effetGradient effectScale callModelRK" data-toggle="modal"
                                           data-name="Request Price Breakup"
                                           data-btn="Send Now"
                                           data-form="lg"
                                           data-target="#rkEnqForm">View Carpet Ares</button> -->
                                             </td>
                                             <td class="price-amt" style="border: 1px solid #dee2e6; text-align:">&#8377; 2.99 Cr* Onwards <br>
                                                <button class="btn btn-primary effetGradient effectScale callModelRK" style="animation: Gradient 3s ease infinite, rocking 2s infinite; animation-delay: 2s;">Price Breakup</button>
                                             </td>

                                          </tr>
                                       </table>
                                       <br>

                                       <center class="d-block d-md-none"><button class="btn sectio-bro-btn callModelRK" style="animation: Gradient 3s ease infinite, rocking 2s infinite; animation-delay: 2s; background-color: #a88944!important; color: #ffffff!important; " data-toggle="modal" data-name="Payment Plan" data-btn="Download Now" data-form="md" data-target="#rkEnqForm">
                                             <img src="assets/svg/site/bro-download.svg" class="nav-svg-icon slideInDown animated infinite" style="animation-duration: 2s;" alt="Prestige City  Download">&nbsp;&nbsp;Payment Plan
                                          </button></center>
                                    </div>

                                    <hr>
                                    <div class="col-sm-4">
                                       <br>
                                       <div style="animation: Gradient 3s ease infinite, rocking 2s infinite; animation-delay: 2s;" class="at-property-dis effetGradient d-none d-md-block" data-toggle="modal" data-name="Complete Costing Details" data-btn="Enquire Now" data-form="lg" data-target="#rkEnqForm">
                                          <h5 style="font-size: 20px;">Payment Plan &nbsp;<img src="assets/svg/site/bro-download.svg" class="nav-svg-icon slideInDown animated infinite" style="animation-duration: 2s; " alt="Prestige City  Download"></h5>
                                       </div>
                                       <div class="complete_costing" data-toggle="modal" data-name="Complete Costing Details" data-btn="Enquire Now" data-form="lg" data-target="#rkEnqForm">
                                          <img src="assets/img/costing-details.jpg" alt="Avatar" class="image" width="100%" style="margin-top: 18px;border: 1px solid grey;">

                                          <div class="overlay2">
                                             <div></div>
                                          </div>
                                          <div class="overlay1">
                                             <div class="text"><button class="btn at-property-btn callModelRK" title="Prestige City  Enqiry">Enquire Now</button></div>
                                          </div>

                                       </div><br>
                                       <div style="animation: Gradient 3s ease infinite, rocking 2s infinite; animation-delay: 2s;" class="at-property-dis effetGradient d-none d-md-block" data-toggle="modal" data-name="Complete Costing Details" data-btn="Enquire Now" data-form="lg" data-target="#rkEnqForm">
                                          <h5 style="font-size: 20px;">Download CostSheet &nbsp;<img src="assets/svg/site/bro-download.svg" class="nav-svg-icon slideInDown animated infinite" style="animation-duration: 2s; " alt="Prestige City  Download"></h5>
                                       </div>

                                       <center class="d-block d-md-none"><button class="btn sectio-bro-btn callModelRK" style="animation: Gradient 3s ease infinite, rocking 2s infinite; animation-delay: 2s; background-color: #a88944!important; color: #ffffff!important;" data-toggle="modal" data-name="Download CostSheet" data-btn="Download CostSheet" data-form="md" data-target="#rkEnqForm">
                                             <img src="assets/svg/site/bro-download.svg" class="nav-svg-icon slideInDown animated infinite" style="animation-duration: 2s;" alt="Prestige City  Download">&nbsp;&nbsp;Download CostSheet
                                          </button></center>
                                    </div>
                                 </div>
                              </div>
                           </div>
                     </section>
                     <br><br>
                     <section class="floor_site_plan" id='siteplans'>
                        <br>
                        <div class="card rk-card">
                           <div class="card-body">
                              <span class="rk-card-header rk-sm-none">Floor Plans</span>
                              <span class="d-md-none rk-card-main-heading" style="text-align: left; margin-bottom:10px"><br>Site & Floor Plan</span>
                              <!-- <h2 class="color-primary rk-md-none">Floor Plans</h2> -->
                              <div class="container site">
                                 <div class="row">
                                    <!-- <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3"> 
                              <div class="first">
                                 <img src="assets/img/plan/lodha-mulund-master1.jpg" alt="Avatar" class="image" width="100%" height="100%" style="border: 1px solid grey;">
                                 <div class="overlay2">
                                    <div></div>
                                 </div>
                                 <div class="overlay1">
                                    <div class="text"><button class="btn callModelRK" data-toggle="modal"
                                    data-name="Mail Me Complete Details"
                                    data-btn="Enquire Now"
                                    data-form="lg"
                                    data-target="#rkEnqForm"
                                    title="Prestige City  Enqiry">Enquire Now</button></div> 
                                 </div>
                                 <div class="cost">
                                    <h5>Master Plan</h5>
                                 </div>
                              </div>
                           </div> -->
                                    <div class="col-lg-4 col-md-4 col-12">
                                       <div class="second" data-toggle="modal" data-name="Mail Me Complete Details" data-btn="Enquire Floor PLan" data-form="lg" data-target="#rkEnqForm">
                                          <img src="assets/img/plan/1 bhk.jpg" alt="Avatar" width="100%" height="auto" class="" style="border: 1px solid grey;">
                                          <div class="overlay2">
                                             <div></div>
                                          </div>
                                          <div class="overlay1">
                                             <div class="text"><button class="btn at-property-btn callModelRK" title="Prestige City  Enqiry">Enquire Now</button></div>
                                          </div>
                                          <div class="at-property-dis effetGradient">
                                             <h5 style="font-size: 20px;">1 BHK</h5>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-12">
                                       <div class="third" data-toggle="modal" data-name="Mail Me Complete Details" data-btn="Enquire Floor PLan" data-form="lg" data-target="#rkEnqForm">
                                          <img src="assets/img/plan/2 bhk.jpg" alt="Avatar" class="" width="100%" height="100%" style="border: 1px solid grey;">
                                          <div class="overlay2">
                                             <div></div>
                                          </div>
                                          <div class="overlay1">
                                             <div class="text"><button class="btn at-property-btn callModelRK" title="Piramal Aranya - Sea olitaire Enqiry">Enquire Now</button></div>
                                          </div>
                                          <div class="at-property-dis effetGradient">
                                             <h5 style="font-size: 20px;">2 BHK</h5>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-12">
                                       <div class="third" data-toggle="modal" data-name="Mail Me Complete Details" data-btn="Enquire Floor PLan" data-form="lg" data-target="#rkEnqForm">
                                          <img src="assets/img/plan/3 bhk.jpg" alt="Avatar" class="" width="100%" height="100%" style="border: 1px solid grey;">
                                          <div class="overlay2">
                                             <div></div>
                                          </div>
                                          <div class="overlay1">
                                             <div class="text"><button class="btn at-property-btn callModelRK" title="Piramal Aranya - Sea olitaire Enqiry">Enquire Now</button></div>
                                          </div>
                                          <div class="at-property-dis effetGradient">
                                             <h5 style="font-size: 20px;">3 BHK</h5>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-12">
                                       <div class="third" data-toggle="modal" data-name="Mail Me Complete Details" data-btn="Enquire Floor PLan" data-form="lg" data-target="#rkEnqForm">
                                          <img src="assets/img/plan/4bhk.jpg" alt="Avatar" class="" width="100%" height="100%" style="border: 1px solid grey;">
                                          <div class="overlay2">
                                             <div></div>
                                          </div>
                                          <div class="overlay1">
                                             <div class="text"><button class="btn at-property-btn callModelRK" title="Piramal Aranya - Sea olitaire Enqiry">Enquire Now</button></div>
                                          </div>
                                          <div class="at-property-dis effetGradient">
                                             <h5 style="font-size: 20px;">4 BHK</h5>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-12">
                                       <div class="third" data-toggle="modal" data-name="Mail Me Complete Details" data-btn="Enquire Floor PLan" data-form="lg" data-target="#rkEnqForm">
                                          <img src="assets/img/plan/master.jpg" alt="Avatar" class="" width="100%" height="100%" style="border: 1px solid grey;">
                                          <div class="overlay2">
                                             <div></div>
                                          </div>
                                          <div class="overlay1">
                                             <div class="text"><button class="btn at-property-btn callModelRK" title="Piramal Aranya - Sea olitaire Enqiry">Enquire Now</button></div>
                                          </div>
                                          <div class="at-property-dis effetGradient">
                                             <h5 style="font-size: 20px;">Master Plan</h5>
                                          </div>
                                       </div>
                                    </div>

                                 </div>

                              </div>
                           </div>
                        </div>
                     </section>


                     <!-- <section class="section shadow-sm lazyloaded"> 
  <span class="section-link" id="gallery"></span> 
  <span class="head text-capitalize">Gallery</span> 
  <div class="ami-2 owl-carousel owl-theme owl-loaded owl-drag">       
    <div class="owl-stage-outer">
      <div class="owl-stage" style="transform: translate3d(-176px, 0px, 0px); transition: all 0.8s ease 0s; width: 1057px;">
        <div class="owl-item" style="width: 166.081px; margin-right: 10px;">
          <div class="item flex-fill"> 
            <a data-fancybox="gallery-0" href="./assets/img/g1.jpg" data-expand="-1" class=" lazyloaded"> 
              <img data-src="./assets/img/g1-320w.jpg" class="img-thumbnail gallery-thumb border border-light lazyloaded" src="./assets/img/g1-320w.jpg"> </a> 
            </div>
          </div>
          <div class="owl-item active" style="width: 166.081px; margin-right: 10px;">
            <div class="item flex-fill"> 
              <a data-fancybox="gallery-0" href="./assets/img/g2.jpg" data-expand="-1" class=" lazyloaded"> 
                <img data-src="./assets/img/g2-320w.jpg" class="img-thumbnail gallery-thumb border border-light lazyloaded" src="./assets/img/g2-320w.jpg"> </a> 
              </div>
            </div>
            <div class="owl-item active" style="width: 166.081px; margin-right: 10px;">
              <div class="item flex-fill">
               <a data-fancybox="gallery-0" href="./assets/img/g3.jpg" data-expand="-1" class=" lazyloaded"> 
                <img data-src="./assets/img/g3-320w.jpg" class="img-thumbnail gallery-thumb border border-light lazyloaded" src="./assets/img/g3-320w.jpg"> </a> 
              </div>
            </div>
            <div class="owl-item active" style="width: 166.081px; margin-right: 10px;"><div class="item flex-fill"> 
              <a data-fancybox="gallery-0" href="./assets/img/g4.jpg" data-expand="-1" class=" lazyloaded"> 
                <img data-src="./assets/img/g4-320w.jpg" class="img-thumbnail gallery-thumb border border-light lazyloaded" src="./assets/img/g4-320w.jpg"> </a> 
              </div>
            </div>
              <div class="owl-item active" style="width: 166.081px; margin-right: 10px;"><div class="item flex-fill"> 
                <a data-fancybox="gallery-0" href="./assets/img/g5.jpg" data-expand="-1" class=" lazyloaded"> 
                  <img data-src="./assets/img/g5-320w.jpg" class="img-thumbnail gallery-thumb border border-light lazyloaded" src="./assets/img/g5-320w.jpg"> </a> 
                </div></div>
                <div class="owl-item active" style="width: 166.081px; margin-right: 10px;"><div class="item flex-fill"> 
                  <a data-fancybox="gallery-0" href="./assets/img/g6.jpg" data-expand="-1" class=" lazyloaded"> 
                    <img data-src="./assets/img/g6-320w.jpg" class="img-thumbnail gallery-thumb border border-light lazyloaded" src="./assets/img/g6-320w.jpg"> 
                  </a> 
                </div>
              </div>
            </div>
          </div>
          <div class="owl-nav">
            <button type="button" role="presentation" class="owl-prev"><span aria-label="Previous">‹</span>
            </button>
            <button type="button" role="presentation" class="owl-next"><span aria-label="Next">›</span>
            </button>
          </div>
          <div class="owl-dots disabled"></div>
        </div> 
      </section> -->




                     <!-- <section class="section shadow-sm lazyloaded" style="background-color: #fff;"> 
      <span class="section-link" id="pricing" style="position: absolute;width: 100%;background-color: transparent;display: block;"></span> 
      <span class="head text-capitalize">Price</span> 
      <div class="row" style="display: flex;margin-right: -15px;margin-left: -15px;"> 
         <div class="col-md-8"> 
            <table class="table table-striped table-borderless border micro-price-table table-pricing" style="width: 100%;margin-bottom: 1rem;"> <thead> 
               <tr> 
                  <th scope="col" class="border border-bottom-0 mb-w" style="border: 1px solid #dee2e6!important;">Type</th> 
                  <th scope="col" class="border border-bottom-0 mb-w" style="border: 1px solid #dee2e6!important;">Rera Carpet</th> 
                  <th scope="col" class="border border-bottom-0 border-right-0" style="border: 1px solid #dee2e6!important;">Price</th> 
                  <th scope="col"></th> 
               </tr> 
            </thead> 
            <tbody> 
               <tr> 
                  <td class="border border-left-0 border-top-0 border-bottom-0 price-type" style="border: 1px solid #dee2e6!important;">1 BHK</td> 
                  <td class="border border-left-0 border-top-0 border-bottom-0 price-carpet" style="border: 1px solid #dee2e6!important;">400 - 425 Sq.Ft <small class="d-inline-block d-md-none">(Rera Carpet)</small></td> 
                  <td class="price-amt" style="border: 1px solid #dee2e6!important;"><i class="mi mi-rs-light"></i> 72 Lacs* Onwards</td> 
                  <td><button class="btn btn-sm btn-info effetGradient effectScale enqModal" data-form="lg" data-title="Send me costing details" data-btn="Send now" data-enquiry="Request Price" data-redirect="floorplan" data-toggle="modal" data-target="#enqModal">Price Breakup</button></td> 
               </tr> 
               <tr> 
                  <td class="border border-left-0 border-top-0 border-bottom-0 price-type" style="border: 1px solid #dee2e6!important;">2 BHK </td> 
                  <td class="border border-left-0 border-top-0 border-bottom-0 price-carpet" style="border: 1px solid #dee2e6!important;">600+ Sq.Ft <small class="d-inline-block d-md-none">(Rera Carpet)</small></td> 
                  <td class="price-amt"><i class="mi mi-rs-light" style="border: 1px solid #dee2e6!important;"></i> 1.04 Cr.* Onwards</td> 
                  <td><button class="btn btn-sm btn-info effetGradient effectScale enqModal" data-form="lg" data-title="Send me costing details" data-btn="Send now" data-enquiry="Request Price" data-redirect="floorplan" data-toggle="modal" data-target="#enqModal">Price Breakup</button></td> 
               </tr> 
            </tbody> 
         </table> 
         <center><b>1+1 and 1+2 jodi options available.</b></center> 
      </div> 
      <div class="col-md-4"> 
         <a href="#" class="text-decoration-none enqModal" data-form="lg" data-title="Send me costing details" data-btn="Send now" data-enquiry="Costing Details" data-toggle="modal" data-target="#enqModal"> 
            <div class="at-property-item shadow-sm border border-grey mt-1" style="position: relative;
    overflow: hidden;"> 
               <div class="at-property-img lazyloaded" data-expand="-1"> 
                  <picture> 
                     <source class=" w-100 lazyloading" data-srcset="assets/img/map.jpg" type="image/svg" srcset="assets/img/map.jpg" sizes="268px"> 
                        <img data-sizes="auto" class="w-100 lazyautosizes lazyloaded ls-inview" data-srcset="assets/img/map.jpg" sizes="268px" srcset="assets/img/map.jpg"> 
                     </picture> 
                     <div class="at-property-overlayer"></div> 
                     <span class="btn btn-default at-property-btn">Enquire Now</span> 
                  </div> 
                  <div class="at-property-dis effetGradient"> 
                     <h5>Complete Costing Details</h5> 
                  </div> 
               </div> 
            </a> 
         </div> 
      </div> 
   </section> -->

                     <!-- <section class="site_plan">
                     <span class="rk-section" id="costing"></span>
                     <div class="card rk-card">
                        <div class="card-body">
                           <span class="rk-card-header rk-sm-none">Site & Floor Plans</span>
                           <h4 class="color-primary rk-md-none">Site & Floor Plans</h4>
                           <div class="rk-card-container">
                             <div class="row">
                              <div class="col-4">
                                 <img src="assets/img/costing-details.jpg" style="border: 1px solid grey;">
                                    <div class="cost" style="background: #a88944;text-align: center;">
                                    <h5 style="font-size: 20px;padding-top: 9px;padding-bottom: 9px;">Complete Costing Details</h5>
                                 </div>
                              </div>
                              <div class="col-4">
                                 <img src="assets/img/costing-details.jpg" style="border: 1px solid grey;">
                                    <div class="cost" style="background: #a88944;text-align: center;">
                                    <h5 style="font-size: 20px;padding-top: 9px;padding-bottom: 9px;">Complete Costing Details</h5>
                                 </div>
                              </div>
                              <div class="col-4">
                                 <img src="assets/img/costing-details.jpg" style="border: 1px solid grey;">
                                    <div class="cost" style="background: #a88944;text-align: center;">
                                    <h5 style="font-size: 20px;padding-top: 9px;padding-bottom: 9px;">Complete Costing Details</h5>
                                 </div>
                              </div>
                             </div>
                           </div>
                        </div>
                     </div>
                  </section> -->


                     <!--   <section class="custom-block">
                     <div class="card rk-card">
                        <div class="card-body">
                           <span class="rk-card-header rk-sm-none">Specifications</span>
                           <h2 class="color-primary rk-md-none">Specifications</h2>
                           <div class="rk-card-container">
                              <div class="row">
                                 <div class="col col-md-12 col-sm-12 ami-block">
                                    <div class="row">
                                       <div class="col-md-6">
                                          <p style="line-height: initial;"></p>
                                          <img src="assets/img/internalfeatures_b.jpg" class=" w-100 img-info">
                                          <ul class="list-group pro-highlights">
                                             <li class="list-group-item"></li>
                                          </ul>
                                       </div>
                                       <div class="col-md-6">
                                          <br>
                                          <ul class="list-group pro-highlights">
                                             <li class="list-group-item" class="list-group-item"></li>
                                             <li class="list-group-item"></li>
                                             <li class="list-group-item"></li>
                                             <li class="list-group-item"></li>
                                             <li class="list-group-item"></li>
                                          </ul>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </section> -->

                     <!--  <section class="location">
                     <span class="rk-section" id=""></span>
                     <div class="card rk-card">
                        <div class="card-body">
                           <span class="rk-card-header rk-sm-none">Master Plan</span>
                           <h2 class="color-primary rk-md-none">Master Plan</h2>
                           <div class="rk-card-container">
                              <div class="row mt-5">
                                 <div class="col-md-12 mb-4">
                                    <div class="col-md-12 overMain">
                                       <center>
                                          <a href="assets/img/mp.jpg" data-toggle="lightbox" >
                                             <div>
                                                <img src="assets/svg/site/loader.svg" data-src="assets/img/mp.jpg" class="lazy" alt="Prestige City  Master Plan" srcset="" >
                                                <div class="overlay">
                                                   <div class="icon">
                                                      <img class="over-icon" src="assets/svg/site/zoom.svg" class="nav-svg-icon" alt="Prestige City  View" >
                                                   </div>
                                                </div>
                                          </a>
                                       </center>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                  </section> -->
                     <br><br>
                     <section class="amenities">
                        <span class="rk-section" id="amenities"></span>
                        <div class="card rk-card ami-div ami-div-h">
                           <div class="card-body">
                              <!-- <span class="rk-card-main-heading" style="text-align: center;">Luxurious Amenities </span> -->
                              <span class="rk-card-header rk-sm-none">Amenities</span>
                              <span class="d-md-none rk-card-main-heading" style="text-align: left; margin-bottom:10px">Amenities</span>
                              <!-- <h2 class="color-primary rk-md-none">Amenities</h2> -->
                              <div class="rk-card-container">
                                 <div class="row col-12" style="margin:0%; padding:0%">
                                    <div class="col-5 col-md-2 col-sm-2 text-center ami-block amenity-custom" style="border: 2px dashed #e4e4e4!important; padding: 10px!important; margin-top:0%" data-toggle="modal" data-name="Mail Me Complete Details" data-btn="Enquire Amenity" data-form="lg" data-target="#rkEnqForm">
                                       <img src="assets/img/amenity/amphitheatre.png">
                                       <span class="ami-title">Amphitheatre</span>
                                    </div>
                                    <div class="col-5 col-md-2 col-sm-2 text-center ami-block amenity-custom" style="border: 2px dashed #e4e4e4!important; padding: 10px!important; margin-top:0%" data-toggle="modal" data-name="Mail Me Complete Details" data-btn="Enquire Amenity" data-form="lg" data-target="#rkEnqForm">
                                       <img src="assets/img/amenity/flags.png">
                                       <span class="ami-title">Event Lawns</span>
                                    </div>
                                    <div class="col-5 col-md-2 col-sm-2 text-center ami-block amenity-custom" style="border: 2px dashed #e4e4e4!important; padding: 10px!important; margin-top:0%" data-toggle="modal" data-name="Mail Me Complete Details" data-btn="Enquire Amenity" data-form="lg" data-target="#rkEnqForm">
                                       <img src="assets/img/amenity/gym.png">
                                       <span class="ami-title">Gym</span>
                                    </div>
                                    <div class="col-5 col-md-2 col-sm-2 text-center ami-block amenity-custom" style="border: 2px dashed #e4e4e4!important; padding: 10px!important; margin-top:0%" data-toggle="modal" data-name="Mail Me Complete Details" data-btn="Enquire Amenity" data-form="lg" data-target="#rkEnqForm">
                                       <img src="assets/img/amenity/kids-play-area.png">
                                       <span class="ami-title">Kids Play Area</span>
                                    </div>
                                    <div class="col-5 col-md-2 col-sm-2 text-center ami-block amenity-custom" style="border: 2px dashed #e4e4e4!important; padding: 10px!important; margin-top:0%" data-toggle="modal" data-name="Mail Me Complete Details" data-btn="Enquire Amenity" data-form="lg" data-target="#rkEnqForm">
                                       <img src="assets/img/amenity/pool.png">
                                       <span class="ami-title">Infinity Pool</span>
                                    </div>
                                    <div class="col-5 col-md-2 col-sm-2 text-center ami-block amenity-custom" style="border: 2px dashed #e4e4e4!important; padding: 10px!important; margin-top:0%" data-toggle="modal" data-name="Mail Me Complete Details" data-btn="Enquire Amenity" data-form="lg" data-target="#rkEnqForm">
                                       <img src="assets/img/amenity/yoga.png">
                                       <span class="ami-title">Yoga</span>
                                    </div>
                                    <div class="col-5 col-md-2 col-sm-2 text-center ami-block amenity-custom" style="border: 2px dashed #e4e4e4!important; padding: 10px!important; margin-top:0%" data-toggle="modal" data-name="Mail Me Complete Details" data-btn="Enquire Amenity" data-form="lg" data-target="#rkEnqForm">
                                       <img src="assets/img/amenity/jogging.png">
                                       <span class="ami-title">Jogging Track</span>
                                    </div>
                                    <div class="col-5 col-md-2 col-sm-2 text-center ami-block amenity-custom" style="border: 2px dashed #e4e4e4!important; padding: 10px!important; margin-top:0%" data-toggle="modal" data-name="Mail Me Complete Details" data-btn="Enquire Amenity" data-form="lg" data-target="#rkEnqForm">
                                       <img src="assets/img/amenity/pitch.png">
                                       <span class="ami-title">Cricket Pitch</span>
                                    </div>
                                    <div class="col-5 col-md-2 col-sm-2 text-center ami-block amenity-custom" style="border: 2px dashed #e4e4e4!important; padding: 10px!important; margin-top:0%" data-toggle="modal" data-name="Mail Me Complete Details" data-btn="Enquire Amenity" data-form="lg" data-target="#rkEnqForm">
                                       <img src="assets/img/amenity/basketball-court.png">
                                       <span class="ami-title">Half Basketball Court</span>
                                    </div>
                                    <div class="col-5 col-md-2 col-sm-2 text-center ami-block amenity-custom" style="border: 2px dashed #e4e4e4!important; padding: 10px!important; margin-top:0%" data-toggle="modal" data-name="Mail Me Complete Details" data-btn="Enquire Amenity" data-form="lg" data-target="#rkEnqForm">
                                       <img src="assets/img/amenity/net.png">
                                       <span class="ami-title">Volleyball Court</span>
                                    </div>



                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                     <br><br>
                     <section class="custom-block" id='gallerysection'>
                        <br>
                        <div class="card rk-card">
                           <div class="card-body">
                              <span class="rk-card-header rk-sm-none">Gallery</span>
                              <!-- <h2 class="color-primary rk-md-none">Gallery</h2> -->
                              <span class="d-md-none rk-card-main-heading" style="text-align: left; margin-bottom:10px"><br>Gallery</span>
                              <div class="rk-card-container">
                                 <div class="row">
                                    <div class="col-12 col-md-12 col-sm-12 ami-block m-top" style="padding: 0%; ">
                                       <div id="customRKSlider" class="m-top carousel slide rk-slider" data-ride="carousel">
                                          <div class="carousel-inner">
                                             <div class="carousel-item">
                                                <img src="assets/img/gallery/Prestige City -slider1.jpg">
                                             </div>
                                             <div class="carousel-item">
                                                <img src="assets/img/gallery/Prestige City -slider2.jpg">
                                             </div>
                                             <div class="carousel-item">
                                                <img src="assets/img/gallery/Prestige City -slider3.jpg">
                                             </div>
                                             <div class="carousel-item">
                                                <img src="assets/img/gallery/Prestige City -slider4.jpg">
                                             </div>
                                             <!--<div class="carousel-item">-->
                                             <!--   <img src="assets/img/gallery/Prestige City -slider5.jpg">-->
                                             <!--</div>-->
                                             <div class="carousel-item">
                                                <img src="assets/img/gallery/Prestige City -slider6.jpg">
                                             </div>
                                             <div class="carousel-item">
                                                <img src="assets/img/gallery/Prestige City -slider7.jpg">
                                             </div>

                                          </div>
                                          <a class="carousel-control-prev" href="#customRKSlider" role="button" data-slide="prev">
                                             <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                             <span class="sr-only">Previous</span>
                                          </a>
                                          <a class="carousel-control-next" href="#customRKSlider" role="button" data-slide="next">
                                             <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                             <span class="sr-only">Next</span>
                                          </a>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                     <br><br>
                     <section class="location">
                        <span class="rk-section" id="location"></span>
                        <div class="card rk-card">
                           <div class="card-body">
                              <span class="rk-card-header rk-sm-none">Location</span>
                              <!-- <h2 class="color-primary rk-md-none">Location</h2> -->
                              <span class="d-md-none rk-card-main-heading" style="text-align: left; margin-bottom:10px">Location Map</span>
                              <div class="rk-card-container">
                                 <ul class="d-none nav nav-pills mb-3 mt-4" id="pills-tab" role="tablist" style="border-radius: 6px;">
                                    <li class="nav-item">
                                       <a class="nav-link rk-tab-btn active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home">Location Map</a>
                                    </li>
                                    <!-- <li class="nav-item">
                                    <a class="nav-link rk-tab-btn" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile">Location Map</a>
                                     </li> -->
                                 </ul>
                                 <div class="tab-content" id="pills-tabContent">
                                    <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                                       <div class="row">
                                          <div class="col-md-6" style="padding:0%;">

                                          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d248926.61897394352!2d77.62524581640625!3d12.876928899999998!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae6f78c3e75109%3A0x65c327b0d8584026!2sThe%20Prestige%20City!5e0!3m2!1sen!2sin!4v1641193971890!5m2!1sen!2sin" width="100%" height="360px" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                          </div>
                                          <div class="col-md-6">

                                             <div class="map" data-toggle="modal" data-name="Mail Me Complete Details" data-btn="Map Enquiry" data-form="lg" data-target="#rkEnqForm">
                                                <img src="assets/img/map.jpg" alt="Avatar" class="" width="100%" height="auto" style="border: 1px solid #333;">

                                                <div class="overlay2">
                                                   <div></div>
                                                </div>
                                                <div class="overlay1">
                                                   <div class="text"><button class="btn callModelRK" title="Prestige City  Enqiry">Enquire Now</button></div>
                                                </div>
                                             </div>
                                          </div>
                                          <!--  <div class="col-md-4 loc-ul-tab">
                              <br>
                           <h3 class="mb-3" style="margin-bottom:5px">Connectivity</h3>
                           <hr style="margin:0%">
                           <ul class="loc-ul" style="">
                           <li>
                           <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12">
                           <path id="icons8-checked-24" d="M7.8,2A5.907,5.907,0,0,0,2,8a5.907,5.907,0,0,0,5.8,6,5.907,5.907,0,0,0,5.8-6,6.153,6.153,0,0,0-.314-1.93l-.938.971A4.969,4.969,0,0,1,12.431,8,4.726,4.726,0,0,1,7.8,12.8,4.726,4.726,0,0,1,3.159,8,4.726,4.726,0,0,1,7.8,3.2a4.5,4.5,0,0,1,2.561.8l.83-.859A5.63,5.63,0,0,0,7.8,2Zm5.385.776L7.216,8.952,5.307,6.976l-.819.848,2.728,2.824L14,3.624Z" transform="translate(-2 -2)" class="svgCheck"/>
                           </svg>
                           <span class="loc-li">Powai Supreme Business Park - 20min</span>
                           </li>
                           
                           </ul>
                           </div> -->
                                       </div>
                                       <p>Bangalore, also known as Bengaluru (Kannada) is the capital of the Indian State of Karnataka. Bangalore is nicknamed the Garden City and was once called a Pensioner's Paradise. Located on the Deccan Plateau in the south-eastern part of Karnataka, Bangalore is India's third most populous city. There are a number of expats from across the world living in the city, thanks to the growing presence of Multi-National Companies.</p>
                                       <div class="rk-card-container">

                                          <!-- <ul class="nav nav-pills mt-4 mb-3 col-md-12 col-12" style="border-radius: 6px; padding:0%" id="pills-tabconn" role="tablist"> 
                                   
                                 <li class="nav-item loc-tab-link"> 
                                    <a class="nav-link text-uppercase ami-tab active" id="pills-loc-0" data-toggle="pill" href="#loc-0" role="tab" aria-controls="loc-0" aria-selected="true">Connectivity</a> 
                                 </li> 
                                           
                              </ul> -->

                                          <div class="tab-content" id="pills-tabconnContent" style=" color: #333333;">
                                             <div class="tab-pane fade active show" id="loc-0" role="tabpanel" aria-labelledby="pills-loc-0">
                                                <div class="row cst-padd">
                                                   <div class="col-12 col-md-4 my-2" style="padding-left: 5px;">
                                                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12">
                                                         <path id="icons8-checked-24" d="M7.8,2A5.907,5.907,0,0,0,2,8a5.907,5.907,0,0,0,5.8,6,5.907,5.907,0,0,0,5.8-6,6.153,6.153,0,0,0-.314-1.93l-.938.971A4.969,4.969,0,0,1,12.431,8,4.726,4.726,0,0,1,7.8,12.8,4.726,4.726,0,0,1,3.159,8,4.726,4.726,0,0,1,7.8,3.2a4.5,4.5,0,0,1,2.561.8l.83-.859A5.63,5.63,0,0,0,7.8,2Zm5.385.776L7.216,8.952,5.307,6.976l-.819.848,2.728,2.824L14,3.624Z" transform="translate(-2 -2)" class="svgCheck" />
                                                      </svg>&nbsp;Govt Primary School - 1.9 Km
                                                   </div>
                                                   <div class="col-12 col-md-4 my-2" style="padding-left: 5px;">
                                                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12">
                                                         <path id="icons8-checked-24" d="M7.8,2A5.907,5.907,0,0,0,2,8a5.907,5.907,0,0,0,5.8,6,5.907,5.907,0,0,0,5.8-6,6.153,6.153,0,0,0-.314-1.93l-.938.971A4.969,4.969,0,0,1,12.431,8,4.726,4.726,0,0,1,7.8,12.8,4.726,4.726,0,0,1,3.159,8,4.726,4.726,0,0,1,7.8,3.2a4.5,4.5,0,0,1,2.561.8l.83-.859A5.63,5.63,0,0,0,7.8,2Zm5.385.776L7.216,8.952,5.307,6.976l-.819.848,2.728,2.824L14,3.624Z" transform="translate(-2 -2)" class="svgCheck" />
                                                      </svg>&nbsp;  Macaulay English High School - 2.3 Km
                                                   </div>
                                                   <div class="col-12 col-md-4 my-2" style="padding-left: 5px;">
                                                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12">
                                                         <path id="icons8-checked-24" d="M7.8,2A5.907,5.907,0,0,0,2,8a5.907,5.907,0,0,0,5.8,6,5.907,5.907,0,0,0,5.8-6,6.153,6.153,0,0,0-.314-1.93l-.938.971A4.969,4.969,0,0,1,12.431,8,4.726,4.726,0,0,1,7.8,12.8,4.726,4.726,0,0,1,3.159,8,4.726,4.726,0,0,1,7.8,3.2a4.5,4.5,0,0,1,2.561.8l.83-.859A5.63,5.63,0,0,0,7.8,2Zm5.385.776L7.216,8.952,5.307,6.976l-.819.848,2.728,2.824L14,3.624Z" transform="translate(-2 -2)" class="svgCheck" />
                                                      </svg>&nbsp; Spandana Hospital - 1.8 Km
                                                   </div>
                                                   <div class="col-12 col-md-4 my-2" style="padding-left: 5px;">
                                                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12">
                                                         <path id="icons8-checked-24" d="M7.8,2A5.907,5.907,0,0,0,2,8a5.907,5.907,0,0,0,5.8,6,5.907,5.907,0,0,0,5.8-6,6.153,6.153,0,0,0-.314-1.93l-.938.971A4.969,4.969,0,0,1,12.431,8,4.726,4.726,0,0,1,7.8,12.8,4.726,4.726,0,0,1,3.159,8,4.726,4.726,0,0,1,7.8,3.2a4.5,4.5,0,0,1,2.561.8l.83-.859A5.63,5.63,0,0,0,7.8,2Zm5.385.776L7.216,8.952,5.307,6.976l-.819.848,2.728,2.824L14,3.624Z" transform="translate(-2 -2)" class="svgCheck" />
                                                      </svg>&nbsp; Kshema Hospital - 6.8 Km
                                                   </div>
                                                   <div class="col-12 col-md-4 my-2" style="padding-left: 5px;">
                                                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12">
                                                         <path id="icons8-checked-24" d="M7.8,2A5.907,5.907,0,0,0,2,8a5.907,5.907,0,0,0,5.8,6,5.907,5.907,0,0,0,5.8-6,6.153,6.153,0,0,0-.314-1.93l-.938.971A4.969,4.969,0,0,1,12.431,8,4.726,4.726,0,0,1,7.8,12.8,4.726,4.726,0,0,1,3.159,8,4.726,4.726,0,0,1,7.8,3.2a4.5,4.5,0,0,1,2.561.8l.83-.859A5.63,5.63,0,0,0,7.8,2Zm5.385.776L7.216,8.952,5.307,6.976l-.819.848,2.728,2.824L14,3.624Z" transform="translate(-2 -2)" class="svgCheck" />
                                                      </svg>&nbsp; Sri Balaji Chithra Mandira - 2.6 Km

                                                   </div>
                                                   <div class="col-12 col-md-4 my-2" style="padding-left: 5px;">
                                                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12">
                                                         <path id="icons8-checked-24" d="M7.8,2A5.907,5.907,0,0,0,2,8a5.907,5.907,0,0,0,5.8,6,5.907,5.907,0,0,0,5.8-6,6.153,6.153,0,0,0-.314-1.93l-.938.971A4.969,4.969,0,0,1,12.431,8,4.726,4.726,0,0,1,7.8,12.8,4.726,4.726,0,0,1,3.159,8,4.726,4.726,0,0,1,7.8,3.2a4.5,4.5,0,0,1,2.561.8l.83-.859A5.63,5.63,0,0,0,7.8,2Zm5.385.776L7.216,8.952,5.307,6.976l-.819.848,2.728,2.824L14,3.624Z" transform="translate(-2 -2)" class="svgCheck" />
                                                      </svg>&nbsp; Daffodils - 1.6 Km  
                                                   </div>

                                                </div>

                                             </div>


                                             <!-- <div class="tab-pane fade" id="loc-1" role="tabpanel" aria-labelledby="pills-loc-1">
                              <div class="col my-2">
                                 <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12">
                                 <path id="icons8-checked-24" d="M7.8,2A5.907,5.907,0,0,0,2,8a5.907,5.907,0,0,0,5.8,6,5.907,5.907,0,0,0,5.8-6,6.153,6.153,0,0,0-.314-1.93l-.938.971A4.969,4.969,0,0,1,12.431,8,4.726,4.726,0,0,1,7.8,12.8,4.726,4.726,0,0,1,3.159,8,4.726,4.726,0,0,1,7.8,3.2a4.5,4.5,0,0,1,2.561.8l.83-.859A5.63,5.63,0,0,0,7.8,2Zm5.385.776L7.216,8.952,5.307,6.976l-.819.848,2.728,2.824L14,3.624Z" transform="translate(-2 -2)" class="svgCheck"/>
                                    </svg>  Raghuleela Mall - 6 mins
                              </div> 
                           </div> -->

                                          </div>

                                       </div>
                                    </div>

                                    <div class="tab-pane fade " id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                                       <div class="row">
                                          <div class="col-md-12 mb-4">
                                             <div class="col-md-12 overMain">
                                                <center>
                                                   <a href="assets/img/map.jpg" data-toggle="lightbox">
                                                      <img class="d-block w-100 lazy" src="assets/svg/site/loader.svg" data-src="assets/img/map.jpg" alt="Prestige City  Location Map" srcset="">
                                                      <div class="overlay">
                                                         <div class="icon">
                                                            <img class="over-icon" src="assets/svg/site/zoom.svg" class="nav-svg-icon" alt="Prestige City  View">
                                                         </div>
                                                      </div>
                                                   </a>
                                                </center>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>

                     <br><br>

                     <section class="sitevisit">
                        <span class="rk-section" id="sitevisit"></span>
                        <div class="card rk-card">
                           <div class="card-body">
                              <span class="rk-card-header rk-sm-none">Virtual Tour</span>
                              <div class="rk-card-container">
                                 <!-- <h2 class="color-primary rk-md-none">Virtual Site Tour</h2> -->
                                 <span class="d-md-none rk-card-main-heading" style="text-align: left; margin-bottom:10px">Virtual Tour</span>
                                 <div class="col-md-12 overMain m-top">
                                    <!-- <video width="100%" class='hidden-lg' height="" src="video/video.mp4" style="border:none; cursor:pointer; margin-bottom:10px" controls=""> 
                      Your browser does not support HTML5 video.
                    </video> -->
                                    <center>
                                       <a class="callModelRK" onclick="setCookie('vSiteStatus', 'OK')" href="javascript:void(0)" data-toggle="modal" data-name="Virtual Site Tour" data-btn="Start Tour" data-form="lg" data-target="#rkEnqForm">
                                          <img class="lazy" src="assets/svg/site/loader.svg" data-src="assets/img/video.jpg" alt="Prestige City  Virtual Site Visit" srcset="">
                                          <div class="overlay">
                                             <div class="icon">
                                                <img class="over-icon" src="assets/svg/site/video-play.svg" class="nav-svg-icon" alt="Prestige City  Play Video">
                                             </div>
                                          </div>
                                          <!-- <button style="border:none; box-shadow:0 0 2px 0 #000000; color:#ffffff; padding: 10px; background:#bb6603">Enquire Now</button> -->
                                       </a>
                                       <!-- <iframe width="100%" height="400" src="https://www.youtube.com/embed/XcrKt8CSTpA" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe> -->

                                       <!-- <img src="assets/Img/gallery/lodha-mulund-VIDEO IMAGE.jpg" width="100%" height="400"> -->
                                    </center>

                                 </div>
                                 <br>
                                 <span class="rk-card-main-heading" style="text-align: left; margin-bottom:10px; color:#a88944; font-weight:500">About Prestige Group</span>
                                 <p>Over the last decade, the Prestige Group has firmly established itself as one of the leading and most successful developers of real estate in India by imprinting its indelible mark across all asset classes. Founded in 1986, the group’s turnover is today in excess of Rs 3518 Cr (for FY 15); a leap that has been inspired by CMD Irfan Razack and marshaled by his brothers Rezwan Razack and Noaman Razack. As of 30th June 2020, the group has completed 247 projects covering 134 million sft, and currently has 45 ongoing projects covering over 53 million sft, 56 mn sft of upcoming projects, and holds a land bank of 262 acres with potential developable area of 27 mn sft.</p>
                                 <img src="assets/img/pdf.png" data-toggle="modal" data-name="Brochure Download" data-btn="Download Now" data-form="md" data-target="#rkEnqForm" class="d-block d-md-none highlight" style="position: fixed; top: 1rem; width: 30px; cursor: pointer; z-index: 100000; right: 6rem;">
                              </div>
                           </div>
                        </div>
                     </section>
                  </div>
               </div>
         </section>

         <div class="d-block d-md-none"><br></div>
         <section class="main-footer main-background">
            <div class="col-md-12 footer main-background">
               <br>
               <p>RERA No : PRM/KA/RERA/1251/308/PR/210928/004316<br>Disclaimer & Privacy Policy : The content is for information purposes only and does not constitute an offer to avail of any service. Prices mentioned are subject to change without notice and properties mentioned are subject to availability. Images for representation purpose only. This is not the official website. Website Only use for an Advertisement Purpose.</p>
               <br><br>
            </div>
         </section>
      </div>
      <div class="col-md-3 main-col pos-fix-sidebar sidebar">
         <div class="organize-block" style="padding-bottom: 0.5rem;">
            <div class="row og-block">
               <div class="col-md-6 rt-b">
                  <a href="#" class="btn btn-org callModelRK text-white" title="Organize Site Visit For Prestige City " data-toggle="modal" data-name="Organize Site Visit" data-btn="Request Site Visit" data-form="lg" data-target="#rkEnqForm">
                     Organize Site Visit
                  </a>
               </div>
               <div class="col-md-6">
                  <a class="btn-org" href="https://api.whatsapp.com/send?phone=+918879046570&amp;text=Hi!%20I'm%20Interested%20In%20Prestige%20City%20Project.%20Please%20Share%20Details." target="_blank" title="Contact With WhatsApp Now For Prestige City "><svg xmlns="http://www.w3.org/2000/svg" width="16" height="20.267" viewBox="0 0 20.181 20.267">
                        <defs>
                           <style>
                              .a,
                              .d {
                                 fill: #fff;
                              }

                              .b {
                                 fill: #cfd8dc;
                              }

                              .c {
                                 fill: #40c351;
                              }

                              .d {
                                 fill-rule: evenodd;
                              }
                           </style>
                        </defs>
                        <g transform="translate(-3.867 -4)">
                           <path class="a" d="M4.867,24.262l1.355-4.946A9.548,9.548,0,1,1,14.5,24.095h0a9.536,9.536,0,0,1-4.563-1.161Z" transform="translate(-0.497 -0.497)" />
                           <path class="a" d="M4.619,24.264a.258.258,0,0,1-.179-.075.254.254,0,0,1-.063-.244L5.7,19.1A9.8,9.8,0,0,1,21.178,7.374,9.8,9.8,0,0,1,9.65,22.952l-4.966,1.3A.247.247,0,0,1,4.619,24.264Z" transform="translate(-0.249 -0.249)" />
                           <path class="b" d="M14,4.5A9.547,9.547,0,0,1,14,23.6h0a9.536,9.536,0,0,1-4.563-1.161L4.37,23.764l1.355-4.946A9.549,9.549,0,0,1,14,4.5M14,23.6h0m0,0h0M14,4A10.053,10.053,0,0,0,5.185,18.885l-1.3,4.746a.5.5,0,0,0,.485.636A.465.465,0,0,0,4.5,24.25l4.871-1.277a10.05,10.05,0,0,0,14.679-8.918A10.05,10.05,0,0,0,14,4Z" />
                           <path class="c" d="M21.78,10.533A7.936,7.936,0,0,0,9.444,20.36l.189.3-.8,2.927,3-.788.291.173a7.916,7.916,0,0,0,4.038,1.106h0A7.936,7.936,0,0,0,21.78,10.533Z" transform="translate(-2.169 -2.092)" />
                           <path class="d" d="M16.83,15.633c-.179-.4-.367-.407-.538-.412-.139-.006-.3-.006-.458-.006a.872.872,0,0,0-.634.3,2.666,2.666,0,0,0-.837,1.99,4.654,4.654,0,0,0,.974,2.467,9.823,9.823,0,0,0,4.076,3.6c2.015.794,2.426.636,2.862.6a2.412,2.412,0,0,0,1.611-1.135,2,2,0,0,0,.139-1.133c-.059-.1-.218-.159-.458-.279s-1.41-.7-1.63-.776-.377-.118-.536.12-.617.776-.756.935-.277.179-.517.061a6.535,6.535,0,0,1-1.917-1.184,7.193,7.193,0,0,1-1.328-1.652c-.139-.238-.016-.367.1-.487s.24-.279.359-.418a1.7,1.7,0,0,0,.238-.4.445.445,0,0,0-.02-.418C17.506,17.283,17.043,16.1,16.83,15.633Z" transform="translate(-5.218 -5.575)" />
                        </g>
                     </svg> +91 88790 46570</a>
               </div>
            </div>
            <div class="pt-1">
               <p class="og-text">or Request a</p>
               <button class="btn py-2 px-3 micro-form-btn-sm effetGradient effectScale callModelRK" data-toggle="modal" title="Call Request For Prestige City " data-name="Immediate Call Back" data-btn="Request Call Now" data-form="sm" data-target="#rkEnqForm">
                  <img src="assets/svg/site/call-back.svg" class="nav-svg-icon" alt="Prestige City  Call Back">&nbsp; +91 88790 46570
                  </butoon>

            </div>
         </div>
         <div class="enq-form p-1 text-center">
            <br>
            <h4 class="enq-heading font-weight-bold">Pre-Register here for Best Offers</h4>

            <form method="POST" action="mail.php">
               <input type="hidden" name="captcha">
               <input type="hidden" name="pname" value="Prestige City ">
               <input type="hidden" name="form_type" value="Call Back Now">
               <div class="col-md-12 mt-3 mb-3">
                  <input type="text" class="form-control rk-input" id="validationCustom01" name="name" placeholder="Name" autocomplete="off" required>
               </div>
               <div class="col-md-12 mt-3 mb-4">
                  <!--<select name="countrycode" class="form-control ccode" style="cursor:pointer" required="required">-->
                  <!--   <option disabled="disabled" value="">Country Code</option>-->
                  <!--   <option data-countryCode="IN" name="countrycode" value="91" selected="selected">India (+91)</option>-->
                  <!--   <option data-countryCode="GB" name="countrycode" value="44">UK (+44)</option>-->
                  <!--   <option data-countryCode="US" name="countrycode" value="1">USA (+1)</option>-->
                  <!--   <optgroup label="Other countries">-->
                  <!--      <option data-countryCode="DZ" name="countrycode" value="213">Algeria (+213)</option>-->
                  <!--      <option data-countryCode="AD" name="countrycode" value="376">Andorra (+376)</option>-->
                  <!--      <option data-countryCode="AO" name="countrycode" value="244">Angola (+244)</option>-->
                  <!--      <option data-countryCode="AI" name="countrycode" value="1264">Anguilla (+1264)</option>-->
                  <!--      <option data-countryCode="AG" name="countrycode" value="1268">Antigua &amp; Barbuda (+1268)</option>-->
                  <!--      <option data-countryCode="AR" name="countrycode" value="54">Argentina (+54)</option>-->
                  <!--      <option data-countryCode="AM" name="countrycode" value="374">Armenia (+374)</option>-->
                  <!--      <option data-countryCode="AW" name="countrycode" value="297">Aruba (+297)</option>-->
                  <!--      <option data-countryCode="AU" name="countrycode" value="61">Australia (+61)</option>-->
                  <!--      <option data-countryCode="AT" value="43">Austria (+43)</option>-->
                  <!--      <option data-countryCode="AZ" name="countrycode" value="994">Azerbaijan (+994)</option>-->
                  <!--      <option data-countryCode="BS" name="countrycode" value="1242">Bahamas (+1242)</option>-->
                  <!--      <option data-countryCode="BH" name="countrycode" value="973">Bahrain (+973)</option>-->
                  <!--      <option data-countryCode="BD" name="countrycode" value="880">Bangladesh (+880)</option>-->
                  <!--      <option data-countryCode="BB" name="countrycode" value="1246">Barbados (+1246)</option>-->
                  <!--      <option data-countryCode="BY" name="countrycode" value="375">Belarus (+375)</option>-->
                  <!--      <option data-countryCode="BE" name="countrycode" value="32">Belgium (+32)</option>-->
                  <!--      <option data-countryCode="BZ" name="countrycode" value="501">Belize (+501)</option>-->
                  <!--      <option data-countryCode="BJ" name="countrycode" value="229">Benin (+229)</option>-->
                  <!--      <option data-countryCode="BM" name="countrycode" value="1441">Bermuda (+1441)</option>-->
                  <!--      <option data-countryCode="BT" name="countrycode" value="975">Bhutan (+975)</option>-->
                  <!--      <option data-countryCode="BO" name="countrycode" value="591">Bolivia (+591)</option>-->
                  <!--      <option data-countryCode="BA" name="countrycode" value="387">Bosnia Herzegovina (+387)</option>-->
                  <!--      <option data-countryCode="BW" name="countrycode" value="267">Botswana (+267)</option>-->
                  <!--      <option data-countryCode="BR" name="countrycode" value="55">Brazil (+55)</option>-->
                  <!--      <option data-countryCode="BN" name="countrycode" value="673">Brunei (+673)</option>-->
                  <!--      <option data-countryCode="BG" name="countrycode" value="359">Bulgaria (+359)</option>-->
                  <!--      <option data-countryCode="BF" name="countrycode" value="226">Burkina Faso (+226)</option>-->
                  <!--      <option data-countryCode="BI" name="countrycode" value="257">Burundi (+257)</option>-->
                  <!--      <option data-countryCode="KH" name="countrycode" value="855">Cambodia (+855)</option>-->
                  <!--      <option data-countryCode="CM" name="countrycode" value="237">Cameroon (+237)</option>-->
                  <!--      <option data-countryCode="CA" name="countrycode" value="1">Canada (+1)</option>-->
                  <!--      <option data-countryCode="CV" name="countrycode" value="238">Cape Verde Islands (+238)</option>-->
                  <!--      <option data-countryCode="KY" name="countrycode" value="1345">Cayman Islands (+1345)</option>-->
                  <!--      <option data-countryCode="CF" name="countrycode" value="236">Central African Republic (+236)</option>-->
                  <!--      <option data-countryCode="CL" name="countrycode" value="56">Chile (+56)</option>-->
                  <!--      <option data-countryCode="CN" name="countrycode" value="86">China (+86)</option>-->
                  <!--      <option data-countryCode="CO" name="countrycode" value="57">Colombia (+57)</option>-->
                  <!--      <option data-countryCode="KM" name="countrycode" value="269">Comoros (+269)</option>-->
                  <!--      <option data-countryCode="CG" name="countrycode" value="242">Congo (+242)</option>-->
                  <!--      <option data-countryCode="CK" name="countrycode" value="682">Cook Islands (+682)</option>-->
                  <!--      <option data-countryCode="CR" name="countrycode" value="506">Costa Rica (+506)</option>-->
                  <!--      <option data-countryCode="HR" name="countrycode" value="385">Croatia (+385)</option>-->
                  <!--      <option data-countryCode="CU" name="countrycode" value="53">Cuba (+53)</option>-->
                  <!--      <option data-countryCode="CY" name="countrycode" value="90392">Cyprus North (+90392)</option>-->
                  <!--      <option data-countryCode="CY" name="countrycode" value="357">Cyprus South (+357)</option>-->
                  <!--      <option data-countryCode="CZ" name="countrycode" value="42">Czech Republic (+42)</option>-->
                  <!--      <option data-countryCode="DK" name="countrycode" value="45">Denmark (+45)</option>-->
                  <!--      <option data-countryCode="DJ" name="countrycode" value="253">Djibouti (+253)</option>-->
                  <!--      <option data-countryCode="DM" name="countrycode" value="1809">Dominica (+1809)</option>-->
                  <!--      <option data-countryCode="DO" name="countrycode" value="1809">Dominican Republic (+1809)</option>-->
                  <!--      <option data-countryCode="EC" name="countrycode" value="593">Ecuador (+593)</option>-->
                  <!--      <option data-countryCode="EG" name="countrycode" value="20">Egypt (+20)</option>-->
                  <!--      <option data-countryCode="SV" name="countrycode" value="503">El Salvador (+503)</option>-->
                  <!--      <option data-countryCode="GQ" name="countrycode" value="240">Equatorial Guinea (+240)</option>-->
                  <!--      <option data-countryCode="ER" name="countrycode" value="291">Eritrea (+291)</option>-->
                  <!--      <option data-countryCode="EE" name="countrycode" value="372">Estonia (+372)</option>-->
                  <!--      <option data-countryCode="ET" name="countrycode" value="251">Ethiopia (+251)</option>-->
                  <!--      <option data-countryCode="FK" name="countrycode" value="500">Falkland Islands (+500)</option>-->
                  <!--      <option data-countryCode="FO" name="countrycode" value="298">Faroe Islands (+298)</option>-->
                  <!--      <option data-countryCode="FJ" name="countrycode" value="679">Fiji (+679)</option>-->
                  <!--      <option data-countryCode="FI" name="countrycode" value="358">Finland (+358)</option>-->
                  <!--      <option data-countryCode="FR" name="countrycode" value="33">France (+33)</option>-->
                  <!--      <option data-countryCode="GF" name="countrycode" value="594">French Guiana (+594)</option>-->
                  <!--      <option data-countryCode="PF" name="countrycode" value="689">French Polynesia (+689)</option>-->
                  <!--      <option data-countryCode="GA" name="countrycode" value="241">Gabon (+241)</option>-->
                  <!--      <option data-countryCode="GM" name="countrycode" value="220">Gambia (+220)</option>-->
                  <!--      <option data-countryCode="GE" name="countrycode" value="7880">Georgia (+7880)</option>-->
                  <!--      <option data-countryCode="DE" name="countrycode" value="49">Germany (+49)</option>-->
                  <!--      <option data-countryCode="GH" name="countrycode" value="233">Ghana (+233)</option>-->
                  <!--      <option data-countryCode="GI" name="countrycode" value="350">Gibraltar (+350)</option>-->
                  <!--      <option data-countryCode="GR" name="countrycode" value="30">Greece (+30)</option>-->
                  <!--      <option data-countryCode="GL" name="countrycode" value="299">Greenland (+299)</option>-->
                  <!--      <option data-countryCode="GD" name="countrycode" value="1473">Grenada (+1473)</option>-->
                  <!--      <option data-countryCode="GP" name="countrycode" value="590">Guadeloupe (+590)</option>-->
                  <!--      <option data-countryCode="GU" name="countrycode" value="671">Guam (+671)</option>-->
                  <!--      <option data-countryCode="GT" name="countrycode" value="502">Guatemala (+502)</option>-->
                  <!--      <option data-countryCode="GN" name="countrycode" value="224">Guinea (+224)</option>-->
                  <!--      <option data-countryCode="GW" name="countrycode" value="245">Guinea - Bissau (+245)</option>-->
                  <!--      <option data-countryCode="GY" name="countrycode" value="592">Guyana (+592)</option>-->
                  <!--      <option data-countryCode="HT" name="countrycode" value="509">Haiti (+509)</option>-->
                  <!--      <option data-countryCode="HN" name="countrycode" value="504">Honduras (+504)</option>-->
                  <!--      <option data-countryCode="HK" name="countrycode" value="852">Hong Kong (+852)</option>-->
                  <!--      <option data-countryCode="HU" name="countrycode" value="36">Hungary (+36)</option>-->
                  <!--      <option data-countryCode="IS" name="countrycode" value="354">Iceland (+354)</option>-->
                  <!--      <option data-countryCode="ID" name="countrycode" value="62">Indonesia (+62)</option>-->
                  <!--      <option data-countryCode="IR" name="countrycode" value="98">Iran (+98)</option>-->
                  <!--      <option data-countryCode="IQ" name="countrycode" value="964">Iraq (+964)</option>-->
                  <!--      <option data-countryCode="IE" name="countrycode" value="353">Ireland (+353)</option>-->
                  <!--      <option data-countryCode="IL" name="countrycode" value="972">Israel (+972)</option>-->
                  <!--      <option data-countryCode="IT" name="countrycode" value="39">Italy (+39)</option>-->
                  <!--      <option data-countryCode="JM" name="countrycode" value="1876">Jamaica (+1876)</option>-->
                  <!--      <option data-countryCode="JP" name="countrycode" value="81">Japan (+81)</option>-->
                  <!--      <option data-countryCode="JO" name="countrycode" value="962">Jordan (+962)</option>-->
                  <!--      <option data-countryCode="KZ" name="countrycode" value="7">Kazakhstan (+7)</option>-->
                  <!--      <option data-countryCode="KE" name="countrycode" value="254">Kenya (+254)</option>-->
                  <!--      <option data-countryCode="KI" name="countrycode" value="686">Kiribati (+686)</option>-->
                  <!--      <option data-countryCode="KP" name="countrycode" value="850">Korea North (+850)</option>-->
                  <!--      <option data-countryCode="KR" name="countrycode" value="82">Korea South (+82)</option>-->
                  <!--      <option data-countryCode="KW" name="countrycode" value="965">Kuwait (+965)</option>-->
                  <!--      <option data-countryCode="KG" name="countrycode" value="996">Kyrgyzstan (+996)</option>-->
                  <!--      <option data-countryCode="LA" name="countrycode" value="856">Laos (+856)</option>-->
                  <!--      <option data-countryCode="LV" name="countrycode" value="371">Latvia (+371)</option>-->
                  <!--      <option data-countryCode="LB" name="countrycode" value="961">Lebanon (+961)</option>-->
                  <!--      <option data-countryCode="LS" name="countrycode" value="266">Lesotho (+266)</option>-->
                  <!--      <option data-countryCode="LR" name="countrycode" value="231">Liberia (+231)</option>-->
                  <!--      <option data-countryCode="LY" name="countrycode" value="218">Libya (+218)</option>-->
                  <!--      <option data-countryCode="LI" name="countrycode" value="417">Liechtenstein (+417)</option>-->
                  <!--      <option data-countryCode="LT" name="countrycode" value="370">Lithuania (+370)</option>-->
                  <!--      <option data-countryCode="LU" name="countrycode" value="352">Luxembourg (+352)</option>-->
                  <!--      <option data-countryCode="MO" name="countrycode" value="853">Macao (+853)</option>-->
                  <!--      <option data-countryCode="MK" name="countrycode" value="389">Macedonia (+389)</option>-->
                  <!--      <option data-countryCode="MG" name="countrycode" value="261">Madagascar (+261)</option>-->
                  <!--      <option data-countryCode="MW" name="countrycode" value="265">Malawi (+265)</option>-->
                  <!--      <option data-countryCode="MY" name="countrycode" value="60">Malaysia (+60)</option>-->
                  <!--      <option data-countryCode="MV" name="countrycode" value="960">Maldives (+960)</option>-->
                  <!--      <option data-countryCode="ML" name="countrycode" value="223">Mali (+223)</option>-->
                  <!--      <option data-countryCode="MT" name="countrycode" value="356">Malta (+356)</option>-->
                  <!--      <option data-countryCode="MH" name="countrycode" value="692">Marshall Islands (+692)</option>-->
                  <!--      <option data-countryCode="MQ" name="countrycode" value="596">Martinique (+596)</option>-->
                  <!--      <option data-countryCode="MR" name="countrycode" value="222">Mauritania (+222)</option>-->
                  <!--      <option data-countryCode="YT" name="countrycode" value="269">Mayotte (+269)</option>-->
                  <!--      <option data-countryCode="MX" name="countrycode" value="52">Mexico (+52)</option>-->
                  <!--      <option data-countryCode="FM" name="countrycode" value="691">Micronesia (+691)</option>-->
                  <!--      <option data-countryCode="MD" name="countrycode" value="373">Moldova (+373)</option>-->
                  <!--      <option data-countryCode="MC" name="countrycode" value="377">Monaco (+377)</option>-->
                  <!--      <option data-countryCode="MN" name="countrycode" value="976">Mongolia (+976)</option>-->
                  <!--      <option data-countryCode="MS" name="countrycode" value="1664">Montserrat (+1664)</option>-->
                  <!--      <option data-countryCode="MA" name="countrycode" value="212">Morocco (+212)</option>-->
                  <!--      <option data-countryCode="MZ" name="countrycode" value="258">Mozambique (+258)</option>-->
                  <!--      <option data-countryCode="MN" name="countrycode" value="95">Myanmar (+95)</option>-->
                  <!--      <option data-countryCode="NA" name="countrycode" value="264">Namibia (+264)</option>-->
                  <!--      <option data-countryCode="NR" name="countrycode" value="674">Nauru (+674)</option>-->
                  <!--      <option data-countryCode="NP" name="countrycode" value="977">Nepal (+977)</option>-->
                  <!--      <option data-countryCode="NL" name="countrycode" value="31">Netherlands (+31)</option>-->
                  <!--      <option data-countryCode="NC" name="countrycode" value="687">New Caledonia (+687)</option>-->
                  <!--      <option data-countryCode="NZ" name="countrycode" value="64">New Zealand (+64)</option>-->
                  <!--      <option data-countryCode="NI" name="countrycode" value="505">Nicaragua (+505)</option>-->
                  <!--      <option data-countryCode="NE" name="countrycode" value="227">Niger (+227)</option>-->
                  <!--      <option data-countryCode="NG" name="countrycode" value="234">Nigeria (+234)</option>-->
                  <!--      <option data-countryCode="NU" name="countrycode" value="683">Niue (+683)</option>-->
                  <!--      <option data-countryCode="NF" name="countrycode" value="672">Norfolk Islands (+672)</option>-->
                  <!--      <option data-countryCode="NP" name="countrycode" value="670">Northern Marianas (+670)</option>-->
                  <!--      <option data-countryCode="NO" name="countrycode" value="47">Norway (+47)</option>-->
                  <!--      <option data-countryCode="OM" name="countrycode" value="968">Oman (+968)</option>-->
                  <!--      <option data-countryCode="PW" name="countrycode" value="680">Palau (+680)</option>-->
                  <!--      <option data-countryCode="PA" name="countrycode" value="507">Panama (+507)</option>-->
                  <!--      <option data-countryCode="PG" name="countrycode" value="675">Papua New Guinea (+675)</option>-->
                  <!--      <option data-countryCode="PY" name="countrycode" value="595">Paraguay (+595)</option>-->
                  <!--      <option data-countryCode="PE" name="countrycode" value="51">Peru (+51)</option>-->
                  <!--      <option data-countryCode="PH" name="countrycode" value="63">Philippines (+63)</option>-->
                  <!--      <option data-countryCode="PL" name="countrycode" value="48">Poland (+48)</option>-->
                  <!--      <option data-countryCode="PT" name="countrycode" value="351">Portugal (+351)</option>-->
                  <!--      <option data-countryCode="PR" name="countrycode" value="1787">Puerto Rico (+1787)</option>-->
                  <!--      <option data-countryCode="QA" name="countrycode" value="974">Qatar (+974)</option>-->
                  <!--      <option data-countryCode="RE" name="countrycode" value="262">Reunion (+262)</option>-->
                  <!--      <option data-countryCode="RO" name="countrycode" value="40">Romania (+40)</option>-->
                  <!--      <option data-countryCode="RU" name="countrycode" value="7">Russia (+7)</option>-->
                  <!--      <option data-countryCode="RW" name="countrycode" value="250">Rwanda (+250)</option>-->
                  <!--      <option data-countryCode="SM" name="countrycode" value="378">San Marino (+378)</option>-->
                  <!--      <option data-countryCode="ST" name="countrycode" value="239">Sao Tome &amp; Principe (+239)</option>-->
                  <!--      <option data-countryCode="SA" name="countrycode" value="966">Saudi Arabia (+966)</option>-->
                  <!--      <option data-countryCode="SN" name="countrycode" value="221">Senegal (+221)</option>-->
                  <!--      <option data-countryCode="CS" name="countrycode" value="381">Serbia (+381)</option>-->
                  <!--      <option data-countryCode="SC" name="countrycode" value="248">Seychelles (+248)</option>-->
                  <!--      <option data-countryCode="SL" name="countrycode" value="232">Sierra Leone (+232)</option>-->
                  <!--      <option data-countryCode="SG" name="countrycode" value="65">Singapore (+65)</option>-->
                  <!--      <option data-countryCode="SK" name="countrycode" value="421">Slovak Republic (+421)</option>-->
                  <!--      <option data-countryCode="SI" name="countrycode" value="386">Slovenia (+386)</option>-->
                  <!--      <option data-countryCode="SB" name="countrycode" value="677">Solomon Islands (+677)</option>-->
                  <!--      <option data-countryCode="SO" name="countrycode" value="252">Somalia (+252)</option>-->
                  <!--      <option data-countryCode="ZA" name="countrycode" value="27">South Africa (+27)</option>-->
                  <!--      <option data-countryCode="ES" name="countrycode" value="34">Spain (+34)</option>-->
                  <!--      <option data-countryCode="LK" name="countrycode" value="94">Sri Lanka (+94)</option>-->
                  <!--      <option data-countryCode="SH" name="countrycode" value="290">St. Helena (+290)</option>-->
                  <!--      <option data-countryCode="KN" name="countrycode" value="1869">St. Kitts (+1869)</option>-->
                  <!--      <option data-countryCode="SC" name="countrycode" value="1758">St. Lucia (+1758)</option>-->
                  <!--      <option data-countryCode="SD" name="countrycode" value="249">Sudan (+249)</option>-->
                  <!--      <option data-countryCode="SR" name="countrycode" value="597">Suriname (+597)</option>-->
                  <!--      <option data-countryCode="SZ" name="countrycode" value="268">Swaziland (+268)</option>-->
                  <!--      <option data-countryCode="SE" name="countrycode" value="46">Sweden (+46)</option>-->
                  <!--      <option data-countryCode="CH" name="countrycode" value="41">Switzerland (+41)</option>-->
                  <!--      <option data-countryCode="SI" name="countrycode" value="963">Syria (+963)</option>-->
                  <!--      <option data-countryCode="TW" name="countrycode" value="886">Taiwan (+886)</option>-->
                  <!--      <option data-countryCode="TJ" name="countrycode" value="7">Tajikstan (+7)</option>-->
                  <!--      <option data-countryCode="TH" name="countrycode" value="66">Thailand (+66)</option>-->
                  <!--      <option data-countryCode="TG" name="countrycode" value="228">Togo (+228)</option>-->
                  <!--      <option data-countryCode="TO" name="countrycode" value="676">Tonga (+676)</option>-->
                  <!--      <option data-countryCode="TT" name="countrycode" value="1868">Trinidad &amp; Tobago (+1868)</option>-->
                  <!--      <option data-countryCode="TN" name="countrycode" value="216">Tunisia (+216)</option>-->
                  <!--      <option data-countryCode="TR" name="countrycode" value="90">Turkey (+90)</option>-->
                  <!--      <option data-countryCode="TM" name="countrycode" value="7">Turkmenistan (+7)</option>-->
                  <!--      <option data-countryCode="TM" name="countrycode" value="993">Turkmenistan (+993)</option>-->
                  <!--      <option data-countryCode="TC" name="countrycode" value="1649">Turks &amp; Caicos Islands (+1649)</option>-->
                  <!--      <option data-countryCode="TV" name="countrycode" value="688">Tuvalu (+688)</option>-->
                  <!--      <option data-countryCode="UG" name="countrycode" value="256">Uganda (+256)</option>-->
                        <!-- <option data-countryCode="GB" value="44">UK (+44)</option> -->
                  <!--      <option data-countryCode="UA" name="countrycode" value="380">Ukraine (+380)</option>-->
                  <!--      <option data-countryCode="AE" name="countrycode" value="971">United Arab Emirates (+971)</option>-->
                  <!--      <option data-countryCode="UY" name="countrycode" value="598">Uruguay (+598)</option>-->
                        <!-- <option data-countryCode="US" value="1">USA (+1)</option> -->
                  <!--      <option data-countryCode="UZ" name="countrycode" value="7">Uzbekistan (+7)</option>-->
                  <!--      <option data-countryCode="VU" name="countrycode" value="678">Vanuatu (+678)</option>-->
                  <!--      <option data-countryCode="VA" name="countrycode" value="379">Vatican City (+379)</option>-->
                  <!--      <option data-countryCode="VE" name="countrycode" value="58">Venezuela (+58)</option>-->
                  <!--      <option data-countryCode="VN" name="countrycode" value="84">Vietnam (+84)</option>-->
                  <!--      <option data-countryCode="VG" name="countrycode" value="84">Virgin Islands - British (+1284)</option>-->
                  <!--      <option data-countryCode="VI" name="countrycode" value="84">Virgin Islands - US (+1340)</option>-->
                  <!--      <option data-countryCode="WF" name="countrycode" value="681">Wallis &amp; Futuna (+681)</option>-->
                  <!--      <option data-countryCode="YE" name="countrycode" value="969">Yemen (North)(+969)</option>-->
                  <!--      <option data-countryCode="YE" name="countrycode" value="967">Yemen (South)(+967)</option>-->
                  <!--      <option data-countryCode="ZM" name="countrycode" value="260">Zambia (+260)</option>-->
                  <!--      <option data-countryCode="ZW" name="countrycode" value="263">Zimbabwe (+263)</option>-->
                  <!--   </optgroup>-->
                  <!--</select>-->
                  <input type="text" class="form-control rk-input" id="validationCustom03" name="phone" placeholder="Mobile No" autocomplete="off" required style="padding-left:">
               </div>
               <div class="col-md-12 mt-3 mb-3">
                  <input type="email" class="form-control rk-input" id="validationCustom02" name="email" placeholder="Email" autocomplete="off" required="">
               </div>
               <button class="btn micro-form-btn-sm effetGradient effectScale py-2 px-5" style="animation: Gradient 3s ease infinite, rocking 2s infinite; animation-delay: 2s;" name="submit" type="submit">Pre-Register Now</button>
            </form>

         </div>

         <!-- <div style="padding: 5px 20px">
         <ul class="hightlight-list" style="color: #000;text-shadow: none; padding:30px;">
           <li><span class="head" style="color: #000000"></span> - Video Door Phone
</li>
           <li><span class="head" style="color: #000000"></span> - Home Automation System</li>
           <li><span class="head" style="color: #000000"></span> - Double Height Grand Entrance Lobby</li>
           <li><span class="head" style="color: #000000"></span> - Sewage Water Recycling Plant</li>
           <li><span class="head" style="color: #000000"></span> - Motion Sensor Solar / LED Lighting</li>
           <li><span class="head" style="color: #000000"></span> - Sprinkler System And Mechanical Ventilation</li>
         </ul>
      </div> -->

         <div class="side-brouchure text-center">
            <h5>For More Information :</h5>
            <button class="btn micro-form-btn-sm effetGradient effectScale py-2 px-5 callModelRK" style="animation: Gradient 3s ease infinite, rocking 2s infinite; animation-delay: 2s;" onclick="setCookie('proBro', 'OK')" data-toggle="modal" data-name="Brochure Download" data-btn="Download Now" data-form="md" data-target="#rkEnqForm">
               Download Brochure
            </button>
         </div>
      </div>
   </div>


   <div class="wp-mb">
      <ul class="nav nav-fill" style="display: flex!important">

         <li class="nav-item">
            <a class="nav-link" href="tel:+918879046570" style="">
               <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 18 17.993">
                  <defs>
                     <style>
                        .a {
                           fill-rule: evenodd;
                           fill: #fff;
                        }
                     </style>
                  </defs>
                  <path class="a" d="M24.53,21.265a8.739,8.739,0,0,0-2.742,2.64c-1.284,3.377,7.523,13.346,13.168,14.9,1.589.439,2.143.244,3.452-1.212,1.852-2.06,1.751-2.5-.969-4.28-2.325-1.518-2.451-1.545-3.846-.839a7.54,7.54,0,0,1-1.143.509,50.52,50.52,0,0,1-4.575-4.514c-.13-.24-.036-.6.32-1.222.755-1.321.668-1.781-.74-3.895-1.659-2.492-1.8-2.6-2.926-2.091m6.008,1.016c0,.424.122.524.764.632a7.376,7.376,0,0,1,6.473,6.255c.125.856.2.967.647.967.492,0,.5-.028.36-1.069-.467-3.444-3.346-6.563-6.446-6.983-.485-.066-1.087-.161-1.339-.212-.377-.076-.458,0-.458.411m-3.97,1.688,1.182,1.777-.677,1.266L26.4,28.278l.845,1.095a30.927,30.927,0,0,0,4.39,4.328l.788.593,1.27-.679,1.27-.679,1.865,1.254c2.124,1.429,2.11,1.338.471,2.941l-1.011.988L35.194,37.8c-4.306-1.255-11.47-8.539-12.38-12.586l-.2-.882,1.105-1.071c1.433-1.388,1.457-1.381,2.846.706m3.97.576c0,.395.136.505.764.619a5.357,5.357,0,0,1,4.232,4.218c.119.633.224.754.654.754.917,0,.192-2.594-1.153-4.126-1.259-1.434-4.5-2.488-4.5-1.464m0,2.191c0,.408.128.544.616.651a3,3,0,0,1,2.06,1.949c.19.635.338.8.716.8.616,0,.63-.573.045-1.782-.743-1.535-3.438-2.8-3.438-1.617" transform="translate(-21.662 -21.022)" />
               </svg>
               &nbsp;Call
            </a>
         </li>
         <li class="nav-item">
            <a class="nav-link callModelRK" href="javascript:void(0)" data-toggle="modal" data-name="Mail Me Complete Details" data-btn="Enquire Now" data-form="lg" data-target="#rkEnqForm" title="Prestige City  Enqiry"><img src="assets/svg/site/msg.svg" style="width:24px; height: 24px;" class="nav-svg-icon" alt="Prestige City  Enqiry">&nbsp;Enquire</a>
         </li>
         <li class="nav-item">
            <a class="nav-link" href="https://api.whatsapp.com/send?phone=+918879046570&amp;text=Hi!%20I'm%20Interested%20In%20Prestige%20City%20Project.%20Please%20Share%20Details.">
               <svg xmlns="http://www.w3.org/2000/svg" width="20px" height="20px" viewBox="0 0 20.181 20.267">
                  <defs>
                     <style>
                        .a,
                        .d {
                           fill: #fff;
                        }

                        .b {
                           fill: #cfd8dc;
                        }

                        .c {
                           fill: #40c351;
                        }

                        .d {
                           fill-rule: evenodd;
                        }
                     </style>
                  </defs>
                  <g transform="translate(-3.867 -4)">
                     <path class="a" d="M4.867,24.262l1.355-4.946A9.548,9.548,0,1,1,14.5,24.095h0a9.536,9.536,0,0,1-4.563-1.161Z" transform="translate(-0.497 -0.497)" />
                     <path class="a" d="M4.619,24.264a.258.258,0,0,1-.179-.075.254.254,0,0,1-.063-.244L5.7,19.1A9.8,9.8,0,0,1,21.178,7.374,9.8,9.8,0,0,1,9.65,22.952l-4.966,1.3A.247.247,0,0,1,4.619,24.264Z" transform="translate(-0.249 -0.249)" />
                     <path class="b" d="M14,4.5A9.547,9.547,0,0,1,14,23.6h0a9.536,9.536,0,0,1-4.563-1.161L4.37,23.764l1.355-4.946A9.549,9.549,0,0,1,14,4.5M14,23.6h0m0,0h0M14,4A10.053,10.053,0,0,0,5.185,18.885l-1.3,4.746a.5.5,0,0,0,.485.636A.465.465,0,0,0,4.5,24.25l4.871-1.277a10.05,10.05,0,0,0,14.679-8.918A10.05,10.05,0,0,0,14,4Z" />
                     <path class="c" d="M21.78,10.533A7.936,7.936,0,0,0,9.444,20.36l.189.3-.8,2.927,3-.788.291.173a7.916,7.916,0,0,0,4.038,1.106h0A7.936,7.936,0,0,0,21.78,10.533Z" transform="translate(-2.169 -2.092)" />
                     <path class="d" d="M16.83,15.633c-.179-.4-.367-.407-.538-.412-.139-.006-.3-.006-.458-.006a.872.872,0,0,0-.634.3,2.666,2.666,0,0,0-.837,1.99,4.654,4.654,0,0,0,.974,2.467,9.823,9.823,0,0,0,4.076,3.6c2.015.794,2.426.636,2.862.6a2.412,2.412,0,0,0,1.611-1.135,2,2,0,0,0,.139-1.133c-.059-.1-.218-.159-.458-.279s-1.41-.7-1.63-.776-.377-.118-.536.12-.617.776-.756.935-.277.179-.517.061a6.535,6.535,0,0,1-1.917-1.184,7.193,7.193,0,0,1-1.328-1.652c-.139-.238-.016-.367.1-.487s.24-.279.359-.418a1.7,1.7,0,0,0,.238-.4.445.445,0,0,0-.02-.418C17.506,17.283,17.043,16.1,16.83,15.633Z" transform="translate(-5.218 -5.575)" />
                  </g>
               </svg>
               &nbsp; Whatsapp
            </a>
         </li>
      </ul>
   </div>

   <!--Auto Pop Modal : autoPopRK-->
   <div class="modal fade" id="autoPopRK" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
         <div class="modal-content">

            <div class="modal-body pb-4">
               <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="font-size: 2rem;">
                  <span aria-hidden="true">&times;</span>
               </button>

               <div class="row">
                  <div class="col-lg-4 text-center">
                     <br>
                     <h2>We Promise</h2>
                     <br>
                     <div style="margin-top: 2px">
                        <img class="form_img" src="assets/img/icons/instant_call_back.png">
                        <p>Instant Call Back</p>
                     </div>

                     <div>
                        <img class="form_img" src="assets/img/icons/free_site_visit.png">
                        <p>Free Site Visit</p>
                     </div>
                     <div>
                        <img class="form_img" src="assets/img/icons/unmatched_price.png">
                        <p>Unmactched Price</p>
                     </div>


                  </div>
                  <div class="col-lg-8 text-center">
                     <div class="text-center mt-4 mb-5">
                        <img src="assets/img/logo/logo.png" class="modal-rk-logo" alt="Prestige City  Logo">
                        <br />
                        <span class="modal-title-secondary" style="font-size: 15px;">Register here and Avail the <span class="text-danger">Best Offers!!</span></span>
                     </div>

                     <form method="POST" action="mail.php">
                        <input type="hidden" name="captcha">
                        <input type="hidden" name="pname" value="Prestige City ">
                        <input type="hidden" name="form_type" value="Auto Onload Popup">
                        <div class="col-md-12 mt-3 mb-4">
                           <input type="text" class="form-control rk-input" placeholder="Name" name="name" autocomplete="off" required>
                           <div class="invalid-feedback">
                              *Please Enter Name
                           </div>
                        </div>
                        <div class="col-md-12 mt-3 mb-4">
                           <!--<select name="countrycode" class="form-control ccode" style="cursor:pointer" required="required">-->
                           <!--   <option disabled="disabled" value="">Country Code</option>-->
                           <!--   <option data-countryCode="IN" name="countrycode" value="91" selected="selected">India (+91)</option>-->
                           <!--   <option data-countryCode="GB" name="countrycode" value="44">UK (+44)</option>-->
                           <!--   <option data-countryCode="US" name="countrycode" value="1">USA (+1)</option>-->
                           <!--   <optgroup label="Other countries">-->
                           <!--      <option data-countryCode="DZ" name="countrycode" value="213">Algeria (+213)</option>-->
                           <!--      <option data-countryCode="AD" name="countrycode" value="376">Andorra (+376)</option>-->
                           <!--      <option data-countryCode="AO" name="countrycode" value="244">Angola (+244)</option>-->
                           <!--      <option data-countryCode="AI" name="countrycode" value="1264">Anguilla (+1264)</option>-->
                           <!--      <option data-countryCode="AG" name="countrycode" value="1268">Antigua &amp; Barbuda (+1268)</option>-->
                           <!--      <option data-countryCode="AR" name="countrycode" value="54">Argentina (+54)</option>-->
                           <!--      <option data-countryCode="AM" name="countrycode" value="374">Armenia (+374)</option>-->
                           <!--      <option data-countryCode="AW" name="countrycode" value="297">Aruba (+297)</option>-->
                           <!--      <option data-countryCode="AU" name="countrycode" value="61">Australia (+61)</option>-->
                           <!--      <option data-countryCode="AT" value="43">Austria (+43)</option>-->
                           <!--      <option data-countryCode="AZ" name="countrycode" value="994">Azerbaijan (+994)</option>-->
                           <!--      <option data-countryCode="BS" name="countrycode" value="1242">Bahamas (+1242)</option>-->
                           <!--      <option data-countryCode="BH" name="countrycode" value="973">Bahrain (+973)</option>-->
                           <!--      <option data-countryCode="BD" name="countrycode" value="880">Bangladesh (+880)</option>-->
                           <!--      <option data-countryCode="BB" name="countrycode" value="1246">Barbados (+1246)</option>-->
                           <!--      <option data-countryCode="BY" name="countrycode" value="375">Belarus (+375)</option>-->
                           <!--      <option data-countryCode="BE" name="countrycode" value="32">Belgium (+32)</option>-->
                           <!--      <option data-countryCode="BZ" name="countrycode" value="501">Belize (+501)</option>-->
                           <!--      <option data-countryCode="BJ" name="countrycode" value="229">Benin (+229)</option>-->
                           <!--      <option data-countryCode="BM" name="countrycode" value="1441">Bermuda (+1441)</option>-->
                           <!--      <option data-countryCode="BT" name="countrycode" value="975">Bhutan (+975)</option>-->
                           <!--      <option data-countryCode="BO" name="countrycode" value="591">Bolivia (+591)</option>-->
                           <!--      <option data-countryCode="BA" name="countrycode" value="387">Bosnia Herzegovina (+387)</option>-->
                           <!--      <option data-countryCode="BW" name="countrycode" value="267">Botswana (+267)</option>-->
                           <!--      <option data-countryCode="BR" name="countrycode" value="55">Brazil (+55)</option>-->
                           <!--      <option data-countryCode="BN" name="countrycode" value="673">Brunei (+673)</option>-->
                           <!--      <option data-countryCode="BG" name="countrycode" value="359">Bulgaria (+359)</option>-->
                           <!--      <option data-countryCode="BF" name="countrycode" value="226">Burkina Faso (+226)</option>-->
                           <!--      <option data-countryCode="BI" name="countrycode" value="257">Burundi (+257)</option>-->
                           <!--      <option data-countryCode="KH" name="countrycode" value="855">Cambodia (+855)</option>-->
                           <!--      <option data-countryCode="CM" name="countrycode" value="237">Cameroon (+237)</option>-->
                           <!--      <option data-countryCode="CA" name="countrycode" value="1">Canada (+1)</option>-->
                           <!--      <option data-countryCode="CV" name="countrycode" value="238">Cape Verde Islands (+238)</option>-->
                           <!--      <option data-countryCode="KY" name="countrycode" value="1345">Cayman Islands (+1345)</option>-->
                           <!--      <option data-countryCode="CF" name="countrycode" value="236">Central African Republic (+236)</option>-->
                           <!--      <option data-countryCode="CL" name="countrycode" value="56">Chile (+56)</option>-->
                           <!--      <option data-countryCode="CN" name="countrycode" value="86">China (+86)</option>-->
                           <!--      <option data-countryCode="CO" name="countrycode" value="57">Colombia (+57)</option>-->
                           <!--      <option data-countryCode="KM" name="countrycode" value="269">Comoros (+269)</option>-->
                           <!--      <option data-countryCode="CG" name="countrycode" value="242">Congo (+242)</option>-->
                           <!--      <option data-countryCode="CK" name="countrycode" value="682">Cook Islands (+682)</option>-->
                           <!--      <option data-countryCode="CR" name="countrycode" value="506">Costa Rica (+506)</option>-->
                           <!--      <option data-countryCode="HR" name="countrycode" value="385">Croatia (+385)</option>-->
                           <!--      <option data-countryCode="CU" name="countrycode" value="53">Cuba (+53)</option>-->
                           <!--      <option data-countryCode="CY" name="countrycode" value="90392">Cyprus North (+90392)</option>-->
                           <!--      <option data-countryCode="CY" name="countrycode" value="357">Cyprus South (+357)</option>-->
                           <!--      <option data-countryCode="CZ" name="countrycode" value="42">Czech Republic (+42)</option>-->
                           <!--      <option data-countryCode="DK" name="countrycode" value="45">Denmark (+45)</option>-->
                           <!--      <option data-countryCode="DJ" name="countrycode" value="253">Djibouti (+253)</option>-->
                           <!--      <option data-countryCode="DM" name="countrycode" value="1809">Dominica (+1809)</option>-->
                           <!--      <option data-countryCode="DO" name="countrycode" value="1809">Dominican Republic (+1809)</option>-->
                           <!--      <option data-countryCode="EC" name="countrycode" value="593">Ecuador (+593)</option>-->
                           <!--      <option data-countryCode="EG" name="countrycode" value="20">Egypt (+20)</option>-->
                           <!--      <option data-countryCode="SV" name="countrycode" value="503">El Salvador (+503)</option>-->
                           <!--      <option data-countryCode="GQ" name="countrycode" value="240">Equatorial Guinea (+240)</option>-->
                           <!--      <option data-countryCode="ER" name="countrycode" value="291">Eritrea (+291)</option>-->
                           <!--      <option data-countryCode="EE" name="countrycode" value="372">Estonia (+372)</option>-->
                           <!--      <option data-countryCode="ET" name="countrycode" value="251">Ethiopia (+251)</option>-->
                           <!--      <option data-countryCode="FK" name="countrycode" value="500">Falkland Islands (+500)</option>-->
                           <!--      <option data-countryCode="FO" name="countrycode" value="298">Faroe Islands (+298)</option>-->
                           <!--      <option data-countryCode="FJ" name="countrycode" value="679">Fiji (+679)</option>-->
                           <!--      <option data-countryCode="FI" name="countrycode" value="358">Finland (+358)</option>-->
                           <!--      <option data-countryCode="FR" name="countrycode" value="33">France (+33)</option>-->
                           <!--      <option data-countryCode="GF" name="countrycode" value="594">French Guiana (+594)</option>-->
                           <!--      <option data-countryCode="PF" name="countrycode" value="689">French Polynesia (+689)</option>-->
                           <!--      <option data-countryCode="GA" name="countrycode" value="241">Gabon (+241)</option>-->
                           <!--      <option data-countryCode="GM" name="countrycode" value="220">Gambia (+220)</option>-->
                           <!--      <option data-countryCode="GE" name="countrycode" value="7880">Georgia (+7880)</option>-->
                           <!--      <option data-countryCode="DE" name="countrycode" value="49">Germany (+49)</option>-->
                           <!--      <option data-countryCode="GH" name="countrycode" value="233">Ghana (+233)</option>-->
                           <!--      <option data-countryCode="GI" name="countrycode" value="350">Gibraltar (+350)</option>-->
                           <!--      <option data-countryCode="GR" name="countrycode" value="30">Greece (+30)</option>-->
                           <!--      <option data-countryCode="GL" name="countrycode" value="299">Greenland (+299)</option>-->
                           <!--      <option data-countryCode="GD" name="countrycode" value="1473">Grenada (+1473)</option>-->
                           <!--      <option data-countryCode="GP" name="countrycode" value="590">Guadeloupe (+590)</option>-->
                           <!--      <option data-countryCode="GU" name="countrycode" value="671">Guam (+671)</option>-->
                           <!--      <option data-countryCode="GT" name="countrycode" value="502">Guatemala (+502)</option>-->
                           <!--      <option data-countryCode="GN" name="countrycode" value="224">Guinea (+224)</option>-->
                           <!--      <option data-countryCode="GW" name="countrycode" value="245">Guinea - Bissau (+245)</option>-->
                           <!--      <option data-countryCode="GY" name="countrycode" value="592">Guyana (+592)</option>-->
                           <!--      <option data-countryCode="HT" name="countrycode" value="509">Haiti (+509)</option>-->
                           <!--      <option data-countryCode="HN" name="countrycode" value="504">Honduras (+504)</option>-->
                           <!--      <option data-countryCode="HK" name="countrycode" value="852">Hong Kong (+852)</option>-->
                           <!--      <option data-countryCode="HU" name="countrycode" value="36">Hungary (+36)</option>-->
                           <!--      <option data-countryCode="IS" name="countrycode" value="354">Iceland (+354)</option>-->
                           <!--      <option data-countryCode="ID" name="countrycode" value="62">Indonesia (+62)</option>-->
                           <!--      <option data-countryCode="IR" name="countrycode" value="98">Iran (+98)</option>-->
                           <!--      <option data-countryCode="IQ" name="countrycode" value="964">Iraq (+964)</option>-->
                           <!--      <option data-countryCode="IE" name="countrycode" value="353">Ireland (+353)</option>-->
                           <!--      <option data-countryCode="IL" name="countrycode" value="972">Israel (+972)</option>-->
                           <!--      <option data-countryCode="IT" name="countrycode" value="39">Italy (+39)</option>-->
                           <!--      <option data-countryCode="JM" name="countrycode" value="1876">Jamaica (+1876)</option>-->
                           <!--      <option data-countryCode="JP" name="countrycode" value="81">Japan (+81)</option>-->
                           <!--      <option data-countryCode="JO" name="countrycode" value="962">Jordan (+962)</option>-->
                           <!--      <option data-countryCode="KZ" name="countrycode" value="7">Kazakhstan (+7)</option>-->
                           <!--      <option data-countryCode="KE" name="countrycode" value="254">Kenya (+254)</option>-->
                           <!--      <option data-countryCode="KI" name="countrycode" value="686">Kiribati (+686)</option>-->
                           <!--      <option data-countryCode="KP" name="countrycode" value="850">Korea North (+850)</option>-->
                           <!--      <option data-countryCode="KR" name="countrycode" value="82">Korea South (+82)</option>-->
                           <!--      <option data-countryCode="KW" name="countrycode" value="965">Kuwait (+965)</option>-->
                           <!--      <option data-countryCode="KG" name="countrycode" value="996">Kyrgyzstan (+996)</option>-->
                           <!--      <option data-countryCode="LA" name="countrycode" value="856">Laos (+856)</option>-->
                           <!--      <option data-countryCode="LV" name="countrycode" value="371">Latvia (+371)</option>-->
                           <!--      <option data-countryCode="LB" name="countrycode" value="961">Lebanon (+961)</option>-->
                           <!--      <option data-countryCode="LS" name="countrycode" value="266">Lesotho (+266)</option>-->
                           <!--      <option data-countryCode="LR" name="countrycode" value="231">Liberia (+231)</option>-->
                           <!--      <option data-countryCode="LY" name="countrycode" value="218">Libya (+218)</option>-->
                           <!--      <option data-countryCode="LI" name="countrycode" value="417">Liechtenstein (+417)</option>-->
                           <!--      <option data-countryCode="LT" name="countrycode" value="370">Lithuania (+370)</option>-->
                           <!--      <option data-countryCode="LU" name="countrycode" value="352">Luxembourg (+352)</option>-->
                           <!--      <option data-countryCode="MO" name="countrycode" value="853">Macao (+853)</option>-->
                           <!--      <option data-countryCode="MK" name="countrycode" value="389">Macedonia (+389)</option>-->
                           <!--      <option data-countryCode="MG" name="countrycode" value="261">Madagascar (+261)</option>-->
                           <!--      <option data-countryCode="MW" name="countrycode" value="265">Malawi (+265)</option>-->
                           <!--      <option data-countryCode="MY" name="countrycode" value="60">Malaysia (+60)</option>-->
                           <!--      <option data-countryCode="MV" name="countrycode" value="960">Maldives (+960)</option>-->
                           <!--      <option data-countryCode="ML" name="countrycode" value="223">Mali (+223)</option>-->
                           <!--      <option data-countryCode="MT" name="countrycode" value="356">Malta (+356)</option>-->
                           <!--      <option data-countryCode="MH" name="countrycode" value="692">Marshall Islands (+692)</option>-->
                           <!--      <option data-countryCode="MQ" name="countrycode" value="596">Martinique (+596)</option>-->
                           <!--      <option data-countryCode="MR" name="countrycode" value="222">Mauritania (+222)</option>-->
                           <!--      <option data-countryCode="YT" name="countrycode" value="269">Mayotte (+269)</option>-->
                           <!--      <option data-countryCode="MX" name="countrycode" value="52">Mexico (+52)</option>-->
                           <!--      <option data-countryCode="FM" name="countrycode" value="691">Micronesia (+691)</option>-->
                           <!--      <option data-countryCode="MD" name="countrycode" value="373">Moldova (+373)</option>-->
                           <!--      <option data-countryCode="MC" name="countrycode" value="377">Monaco (+377)</option>-->
                           <!--      <option data-countryCode="MN" name="countrycode" value="976">Mongolia (+976)</option>-->
                           <!--      <option data-countryCode="MS" name="countrycode" value="1664">Montserrat (+1664)</option>-->
                           <!--      <option data-countryCode="MA" name="countrycode" value="212">Morocco (+212)</option>-->
                           <!--      <option data-countryCode="MZ" name="countrycode" value="258">Mozambique (+258)</option>-->
                           <!--      <option data-countryCode="MN" name="countrycode" value="95">Myanmar (+95)</option>-->
                           <!--      <option data-countryCode="NA" name="countrycode" value="264">Namibia (+264)</option>-->
                           <!--      <option data-countryCode="NR" name="countrycode" value="674">Nauru (+674)</option>-->
                           <!--      <option data-countryCode="NP" name="countrycode" value="977">Nepal (+977)</option>-->
                           <!--      <option data-countryCode="NL" name="countrycode" value="31">Netherlands (+31)</option>-->
                           <!--      <option data-countryCode="NC" name="countrycode" value="687">New Caledonia (+687)</option>-->
                           <!--      <option data-countryCode="NZ" name="countrycode" value="64">New Zealand (+64)</option>-->
                           <!--      <option data-countryCode="NI" name="countrycode" value="505">Nicaragua (+505)</option>-->
                           <!--      <option data-countryCode="NE" name="countrycode" value="227">Niger (+227)</option>-->
                           <!--      <option data-countryCode="NG" name="countrycode" value="234">Nigeria (+234)</option>-->
                           <!--      <option data-countryCode="NU" name="countrycode" value="683">Niue (+683)</option>-->
                           <!--      <option data-countryCode="NF" name="countrycode" value="672">Norfolk Islands (+672)</option>-->
                           <!--      <option data-countryCode="NP" name="countrycode" value="670">Northern Marianas (+670)</option>-->
                           <!--      <option data-countryCode="NO" name="countrycode" value="47">Norway (+47)</option>-->
                           <!--      <option data-countryCode="OM" name="countrycode" value="968">Oman (+968)</option>-->
                           <!--      <option data-countryCode="PW" name="countrycode" value="680">Palau (+680)</option>-->
                           <!--      <option data-countryCode="PA" name="countrycode" value="507">Panama (+507)</option>-->
                           <!--      <option data-countryCode="PG" name="countrycode" value="675">Papua New Guinea (+675)</option>-->
                           <!--      <option data-countryCode="PY" name="countrycode" value="595">Paraguay (+595)</option>-->
                           <!--      <option data-countryCode="PE" name="countrycode" value="51">Peru (+51)</option>-->
                           <!--      <option data-countryCode="PH" name="countrycode" value="63">Philippines (+63)</option>-->
                           <!--      <option data-countryCode="PL" name="countrycode" value="48">Poland (+48)</option>-->
                           <!--      <option data-countryCode="PT" name="countrycode" value="351">Portugal (+351)</option>-->
                           <!--      <option data-countryCode="PR" name="countrycode" value="1787">Puerto Rico (+1787)</option>-->
                           <!--      <option data-countryCode="QA" name="countrycode" value="974">Qatar (+974)</option>-->
                           <!--      <option data-countryCode="RE" name="countrycode" value="262">Reunion (+262)</option>-->
                           <!--      <option data-countryCode="RO" name="countrycode" value="40">Romania (+40)</option>-->
                           <!--      <option data-countryCode="RU" name="countrycode" value="7">Russia (+7)</option>-->
                           <!--      <option data-countryCode="RW" name="countrycode" value="250">Rwanda (+250)</option>-->
                           <!--      <option data-countryCode="SM" name="countrycode" value="378">San Marino (+378)</option>-->
                           <!--      <option data-countryCode="ST" name="countrycode" value="239">Sao Tome &amp; Principe (+239)</option>-->
                           <!--      <option data-countryCode="SA" name="countrycode" value="966">Saudi Arabia (+966)</option>-->
                           <!--      <option data-countryCode="SN" name="countrycode" value="221">Senegal (+221)</option>-->
                           <!--      <option data-countryCode="CS" name="countrycode" value="381">Serbia (+381)</option>-->
                           <!--      <option data-countryCode="SC" name="countrycode" value="248">Seychelles (+248)</option>-->
                           <!--      <option data-countryCode="SL" name="countrycode" value="232">Sierra Leone (+232)</option>-->
                           <!--      <option data-countryCode="SG" name="countrycode" value="65">Singapore (+65)</option>-->
                           <!--      <option data-countryCode="SK" name="countrycode" value="421">Slovak Republic (+421)</option>-->
                           <!--      <option data-countryCode="SI" name="countrycode" value="386">Slovenia (+386)</option>-->
                           <!--      <option data-countryCode="SB" name="countrycode" value="677">Solomon Islands (+677)</option>-->
                           <!--      <option data-countryCode="SO" name="countrycode" value="252">Somalia (+252)</option>-->
                           <!--      <option data-countryCode="ZA" name="countrycode" value="27">South Africa (+27)</option>-->
                           <!--      <option data-countryCode="ES" name="countrycode" value="34">Spain (+34)</option>-->
                           <!--      <option data-countryCode="LK" name="countrycode" value="94">Sri Lanka (+94)</option>-->
                           <!--      <option data-countryCode="SH" name="countrycode" value="290">St. Helena (+290)</option>-->
                           <!--      <option data-countryCode="KN" name="countrycode" value="1869">St. Kitts (+1869)</option>-->
                           <!--      <option data-countryCode="SC" name="countrycode" value="1758">St. Lucia (+1758)</option>-->
                           <!--      <option data-countryCode="SD" name="countrycode" value="249">Sudan (+249)</option>-->
                           <!--      <option data-countryCode="SR" name="countrycode" value="597">Suriname (+597)</option>-->
                           <!--      <option data-countryCode="SZ" name="countrycode" value="268">Swaziland (+268)</option>-->
                           <!--      <option data-countryCode="SE" name="countrycode" value="46">Sweden (+46)</option>-->
                           <!--      <option data-countryCode="CH" name="countrycode" value="41">Switzerland (+41)</option>-->
                           <!--      <option data-countryCode="SI" name="countrycode" value="963">Syria (+963)</option>-->
                           <!--      <option data-countryCode="TW" name="countrycode" value="886">Taiwan (+886)</option>-->
                           <!--      <option data-countryCode="TJ" name="countrycode" value="7">Tajikstan (+7)</option>-->
                           <!--      <option data-countryCode="TH" name="countrycode" value="66">Thailand (+66)</option>-->
                           <!--      <option data-countryCode="TG" name="countrycode" value="228">Togo (+228)</option>-->
                           <!--      <option data-countryCode="TO" name="countrycode" value="676">Tonga (+676)</option>-->
                           <!--      <option data-countryCode="TT" name="countrycode" value="1868">Trinidad &amp; Tobago (+1868)</option>-->
                           <!--      <option data-countryCode="TN" name="countrycode" value="216">Tunisia (+216)</option>-->
                           <!--      <option data-countryCode="TR" name="countrycode" value="90">Turkey (+90)</option>-->
                           <!--      <option data-countryCode="TM" name="countrycode" value="7">Turkmenistan (+7)</option>-->
                           <!--      <option data-countryCode="TM" name="countrycode" value="993">Turkmenistan (+993)</option>-->
                           <!--      <option data-countryCode="TC" name="countrycode" value="1649">Turks &amp; Caicos Islands (+1649)</option>-->
                           <!--      <option data-countryCode="TV" name="countrycode" value="688">Tuvalu (+688)</option>-->
                           <!--      <option data-countryCode="UG" name="countrycode" value="256">Uganda (+256)</option>-->
                                 <!-- <option data-countryCode="GB" value="44">UK (+44)</option> -->
                           <!--      <option data-countryCode="UA" name="countrycode" value="380">Ukraine (+380)</option>-->
                           <!--      <option data-countryCode="AE" name="countrycode" value="971">United Arab Emirates (+971)</option>-->
                           <!--      <option data-countryCode="UY" name="countrycode" value="598">Uruguay (+598)</option>-->
                                 <!-- <option data-countryCode="US" value="1">USA (+1)</option> -->
                           <!--      <option data-countryCode="UZ" name="countrycode" value="7">Uzbekistan (+7)</option>-->
                           <!--      <option data-countryCode="VU" name="countrycode" value="678">Vanuatu (+678)</option>-->
                           <!--      <option data-countryCode="VA" name="countrycode" value="379">Vatican City (+379)</option>-->
                           <!--      <option data-countryCode="VE" name="countrycode" value="58">Venezuela (+58)</option>-->
                           <!--      <option data-countryCode="VN" name="countrycode" value="84">Vietnam (+84)</option>-->
                           <!--      <option data-countryCode="VG" name="countrycode" value="84">Virgin Islands - British (+1284)</option>-->
                           <!--      <option data-countryCode="VI" name="countrycode" value="84">Virgin Islands - US (+1340)</option>-->
                           <!--      <option data-countryCode="WF" name="countrycode" value="681">Wallis &amp; Futuna (+681)</option>-->
                           <!--      <option data-countryCode="YE" name="countrycode" value="969">Yemen (North)(+969)</option>-->
                           <!--      <option data-countryCode="YE" name="countrycode" value="967">Yemen (South)(+967)</option>-->
                           <!--      <option data-countryCode="ZM" name="countrycode" value="260">Zambia (+260)</option>-->
                           <!--      <option data-countryCode="ZW" name="countrycode" value="263">Zimbabwe (+263)</option>-->
                           <!--   </optgroup>-->
                           <!--</select>-->
                           <input type="text" class="form-control rk-input" placeholder="Mobile" name="phone" autocomplete="off" required style='padding-left:'>
                           <div class="invalid-feedback">
                              *Please Enter Valid Number
                           </div>
                        </div>
                        <div class="col-md-12 mt-3 mb-4">
                           <input type="email" class="form-control rk-input" placeholder="Email Address" name="email" autocomplete="off" required="">
                           <div class="invalid-feedback">
                              *Please Enter Valid Email Address
                           </div>
                           <div class="form-group">
                              <br>
                              <button class="btn micro-form-btn effetGradient effectScale effetMoveGradient" name="submit" type="submit">Get Instant Call Back</button>
                           </div>
                     </form>
                  </div>
               </div>
            </div>


         </div>

         <div class="rk-modal-footer-fill">
            <a class="rk-modal-call-link" href="tel:+918879046570">
               <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 18 17.993">
                  <defs>
                     <style>
                        .a {
                           fill-rule: evenodd;
                           fill: #fff;
                        }
                     </style>
                  </defs>
                  <path class="a" d="M24.53,21.265a8.739,8.739,0,0,0-2.742,2.64c-1.284,3.377,7.523,13.346,13.168,14.9,1.589.439,2.143.244,3.452-1.212,1.852-2.06,1.751-2.5-.969-4.28-2.325-1.518-2.451-1.545-3.846-.839a7.54,7.54,0,0,1-1.143.509,50.52,50.52,0,0,1-4.575-4.514c-.13-.24-.036-.6.32-1.222.755-1.321.668-1.781-.74-3.895-1.659-2.492-1.8-2.6-2.926-2.091m6.008,1.016c0,.424.122.524.764.632a7.376,7.376,0,0,1,6.473,6.255c.125.856.2.967.647.967.492,0,.5-.028.36-1.069-.467-3.444-3.346-6.563-6.446-6.983-.485-.066-1.087-.161-1.339-.212-.377-.076-.458,0-.458.411m-3.97,1.688,1.182,1.777-.677,1.266L26.4,28.278l.845,1.095a30.927,30.927,0,0,0,4.39,4.328l.788.593,1.27-.679,1.27-.679,1.865,1.254c2.124,1.429,2.11,1.338.471,2.941l-1.011.988L35.194,37.8c-4.306-1.255-11.47-8.539-12.38-12.586l-.2-.882,1.105-1.071c1.433-1.388,1.457-1.381,2.846.706m3.97.576c0,.395.136.505.764.619a5.357,5.357,0,0,1,4.232,4.218c.119.633.224.754.654.754.917,0,.192-2.594-1.153-4.126-1.259-1.434-4.5-2.488-4.5-1.464m0,2.191c0,.408.128.544.616.651a3,3,0,0,1,2.06,1.949c.19.635.338.8.716.8.616,0,.63-.573.045-1.782-.743-1.535-3.438-2.8-3.438-1.617" transform="translate(-21.662 -21.022)" />
               </svg>
               &nbsp;+91 8879046570
            </a>
         </div>
      </div>
   </div>
   </div>

   <!--Enquiry Modal-->
   <div class="modal fade" id="rkEnqForm" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
         <div class="modal-content">

            <div class="modal-body pb-4">
               <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="font-size: 2rem;">
                  <span aria-hidden="true">&times;</span>
               </button>

               <div class="row">
                  <div class="col-lg-4 text-center">
                     <br>
                     <h2>We Promise</h2>
                     <br>
                     <div style="margin-top: 2px">
                        <img class="form_img" src="assets/img/icons/instant_call_back.png">
                        <p>Instant Call Back</p>
                     </div>

                     <div>
                        <img class="form_img" src="assets/img/icons/free_site_visit.png">
                        <p>Free Site Visit</p>
                     </div>
                     <div>
                        <img class="form_img" src="assets/img/icons/unmatched_price.png">
                        <p>Unmactched Price</p>
                     </div>


                  </div>
                  <div class="col-lg-8 text-center">
                     <div class="text-center mt-4 mb-5">
                        <img src="assets/img/logo/logo.png" class="modal-rk-logo" alt="Prestige City  Logo">
                        <br>
                        <span class="modal-title-secondary" style="font-size: 15px;">Register here and Avail the <span class="text-danger">Best Offers!!</span></span>
                     </div>

                     <form method="POST" action="mail.php">
                        <input type="hidden" name="captcha">
                        <input type="hidden" name="pname" value="Prestige City ">
                        <input type="hidden" name="form_type" value="Enquiry Form">
                        <div class="col-md-12 mt-3 mb-4">
                           <input type="text" class="form-control rk-input" placeholder="Name" name="name" autocomplete="off" required>
                           <div class="invalid-feedback">
                              *Please Enter Name
                           </div>
                        </div>
                        <div class="col-md-12 mt-3 mb-4">
                           <!--<select name="countrycode" class="form-control ccode" style="cursor:pointer" required="required">-->
                           <!--   <option disabled="disabled" value="">Country Code</option>-->
                           <!--   <option data-countryCode="IN" name="countrycode" value="91" selected="selected">India (+91)</option>-->
                           <!--   <option data-countryCode="GB" name="countrycode" value="44">UK (+44)</option>-->
                           <!--   <option data-countryCode="US" name="countrycode" value="1">USA (+1)</option>-->
                           <!--   <optgroup label="Other countries">-->
                           <!--      <option data-countryCode="DZ" name="countrycode" value="213">Algeria (+213)</option>-->
                           <!--      <option data-countryCode="AD" name="countrycode" value="376">Andorra (+376)</option>-->
                           <!--      <option data-countryCode="AO" name="countrycode" value="244">Angola (+244)</option>-->
                           <!--      <option data-countryCode="AI" name="countrycode" value="1264">Anguilla (+1264)</option>-->
                           <!--      <option data-countryCode="AG" name="countrycode" value="1268">Antigua &amp; Barbuda (+1268)</option>-->
                           <!--      <option data-countryCode="AR" name="countrycode" value="54">Argentina (+54)</option>-->
                           <!--      <option data-countryCode="AM" name="countrycode" value="374">Armenia (+374)</option>-->
                           <!--      <option data-countryCode="AW" name="countrycode" value="297">Aruba (+297)</option>-->
                           <!--      <option data-countryCode="AU" name="countrycode" value="61">Australia (+61)</option>-->
                           <!--      <option data-countryCode="AT" value="43">Austria (+43)</option>-->
                           <!--      <option data-countryCode="AZ" name="countrycode" value="994">Azerbaijan (+994)</option>-->
                           <!--      <option data-countryCode="BS" name="countrycode" value="1242">Bahamas (+1242)</option>-->
                           <!--      <option data-countryCode="BH" name="countrycode" value="973">Bahrain (+973)</option>-->
                           <!--      <option data-countryCode="BD" name="countrycode" value="880">Bangladesh (+880)</option>-->
                           <!--      <option data-countryCode="BB" name="countrycode" value="1246">Barbados (+1246)</option>-->
                           <!--      <option data-countryCode="BY" name="countrycode" value="375">Belarus (+375)</option>-->
                           <!--      <option data-countryCode="BE" name="countrycode" value="32">Belgium (+32)</option>-->
                           <!--      <option data-countryCode="BZ" name="countrycode" value="501">Belize (+501)</option>-->
                           <!--      <option data-countryCode="BJ" name="countrycode" value="229">Benin (+229)</option>-->
                           <!--      <option data-countryCode="BM" name="countrycode" value="1441">Bermuda (+1441)</option>-->
                           <!--      <option data-countryCode="BT" name="countrycode" value="975">Bhutan (+975)</option>-->
                           <!--      <option data-countryCode="BO" name="countrycode" value="591">Bolivia (+591)</option>-->
                           <!--      <option data-countryCode="BA" name="countrycode" value="387">Bosnia Herzegovina (+387)</option>-->
                           <!--      <option data-countryCode="BW" name="countrycode" value="267">Botswana (+267)</option>-->
                           <!--      <option data-countryCode="BR" name="countrycode" value="55">Brazil (+55)</option>-->
                           <!--      <option data-countryCode="BN" name="countrycode" value="673">Brunei (+673)</option>-->
                           <!--      <option data-countryCode="BG" name="countrycode" value="359">Bulgaria (+359)</option>-->
                           <!--      <option data-countryCode="BF" name="countrycode" value="226">Burkina Faso (+226)</option>-->
                           <!--      <option data-countryCode="BI" name="countrycode" value="257">Burundi (+257)</option>-->
                           <!--      <option data-countryCode="KH" name="countrycode" value="855">Cambodia (+855)</option>-->
                           <!--      <option data-countryCode="CM" name="countrycode" value="237">Cameroon (+237)</option>-->
                           <!--      <option data-countryCode="CA" name="countrycode" value="1">Canada (+1)</option>-->
                           <!--      <option data-countryCode="CV" name="countrycode" value="238">Cape Verde Islands (+238)</option>-->
                           <!--      <option data-countryCode="KY" name="countrycode" value="1345">Cayman Islands (+1345)</option>-->
                           <!--      <option data-countryCode="CF" name="countrycode" value="236">Central African Republic (+236)</option>-->
                           <!--      <option data-countryCode="CL" name="countrycode" value="56">Chile (+56)</option>-->
                           <!--      <option data-countryCode="CN" name="countrycode" value="86">China (+86)</option>-->
                           <!--      <option data-countryCode="CO" name="countrycode" value="57">Colombia (+57)</option>-->
                           <!--      <option data-countryCode="KM" name="countrycode" value="269">Comoros (+269)</option>-->
                           <!--      <option data-countryCode="CG" name="countrycode" value="242">Congo (+242)</option>-->
                           <!--      <option data-countryCode="CK" name="countrycode" value="682">Cook Islands (+682)</option>-->
                           <!--      <option data-countryCode="CR" name="countrycode" value="506">Costa Rica (+506)</option>-->
                           <!--      <option data-countryCode="HR" name="countrycode" value="385">Croatia (+385)</option>-->
                           <!--      <option data-countryCode="CU" name="countrycode" value="53">Cuba (+53)</option>-->
                           <!--      <option data-countryCode="CY" name="countrycode" value="90392">Cyprus North (+90392)</option>-->
                           <!--      <option data-countryCode="CY" name="countrycode" value="357">Cyprus South (+357)</option>-->
                           <!--      <option data-countryCode="CZ" name="countrycode" value="42">Czech Republic (+42)</option>-->
                           <!--      <option data-countryCode="DK" name="countrycode" value="45">Denmark (+45)</option>-->
                           <!--      <option data-countryCode="DJ" name="countrycode" value="253">Djibouti (+253)</option>-->
                           <!--      <option data-countryCode="DM" name="countrycode" value="1809">Dominica (+1809)</option>-->
                           <!--      <option data-countryCode="DO" name="countrycode" value="1809">Dominican Republic (+1809)</option>-->
                           <!--      <option data-countryCode="EC" name="countrycode" value="593">Ecuador (+593)</option>-->
                           <!--      <option data-countryCode="EG" name="countrycode" value="20">Egypt (+20)</option>-->
                           <!--      <option data-countryCode="SV" name="countrycode" value="503">El Salvador (+503)</option>-->
                           <!--      <option data-countryCode="GQ" name="countrycode" value="240">Equatorial Guinea (+240)</option>-->
                           <!--      <option data-countryCode="ER" name="countrycode" value="291">Eritrea (+291)</option>-->
                           <!--      <option data-countryCode="EE" name="countrycode" value="372">Estonia (+372)</option>-->
                           <!--      <option data-countryCode="ET" name="countrycode" value="251">Ethiopia (+251)</option>-->
                           <!--      <option data-countryCode="FK" name="countrycode" value="500">Falkland Islands (+500)</option>-->
                           <!--      <option data-countryCode="FO" name="countrycode" value="298">Faroe Islands (+298)</option>-->
                           <!--      <option data-countryCode="FJ" name="countrycode" value="679">Fiji (+679)</option>-->
                           <!--      <option data-countryCode="FI" name="countrycode" value="358">Finland (+358)</option>-->
                           <!--      <option data-countryCode="FR" name="countrycode" value="33">France (+33)</option>-->
                           <!--      <option data-countryCode="GF" name="countrycode" value="594">French Guiana (+594)</option>-->
                           <!--      <option data-countryCode="PF" name="countrycode" value="689">French Polynesia (+689)</option>-->
                           <!--      <option data-countryCode="GA" name="countrycode" value="241">Gabon (+241)</option>-->
                           <!--      <option data-countryCode="GM" name="countrycode" value="220">Gambia (+220)</option>-->
                           <!--      <option data-countryCode="GE" name="countrycode" value="7880">Georgia (+7880)</option>-->
                           <!--      <option data-countryCode="DE" name="countrycode" value="49">Germany (+49)</option>-->
                           <!--      <option data-countryCode="GH" name="countrycode" value="233">Ghana (+233)</option>-->
                           <!--      <option data-countryCode="GI" name="countrycode" value="350">Gibraltar (+350)</option>-->
                           <!--      <option data-countryCode="GR" name="countrycode" value="30">Greece (+30)</option>-->
                           <!--      <option data-countryCode="GL" name="countrycode" value="299">Greenland (+299)</option>-->
                           <!--      <option data-countryCode="GD" name="countrycode" value="1473">Grenada (+1473)</option>-->
                           <!--      <option data-countryCode="GP" name="countrycode" value="590">Guadeloupe (+590)</option>-->
                           <!--      <option data-countryCode="GU" name="countrycode" value="671">Guam (+671)</option>-->
                           <!--      <option data-countryCode="GT" name="countrycode" value="502">Guatemala (+502)</option>-->
                           <!--      <option data-countryCode="GN" name="countrycode" value="224">Guinea (+224)</option>-->
                           <!--      <option data-countryCode="GW" name="countrycode" value="245">Guinea - Bissau (+245)</option>-->
                           <!--      <option data-countryCode="GY" name="countrycode" value="592">Guyana (+592)</option>-->
                           <!--      <option data-countryCode="HT" name="countrycode" value="509">Haiti (+509)</option>-->
                           <!--      <option data-countryCode="HN" name="countrycode" value="504">Honduras (+504)</option>-->
                           <!--      <option data-countryCode="HK" name="countrycode" value="852">Hong Kong (+852)</option>-->
                           <!--      <option data-countryCode="HU" name="countrycode" value="36">Hungary (+36)</option>-->
                           <!--      <option data-countryCode="IS" name="countrycode" value="354">Iceland (+354)</option>-->
                           <!--      <option data-countryCode="ID" name="countrycode" value="62">Indonesia (+62)</option>-->
                           <!--      <option data-countryCode="IR" name="countrycode" value="98">Iran (+98)</option>-->
                           <!--      <option data-countryCode="IQ" name="countrycode" value="964">Iraq (+964)</option>-->
                           <!--      <option data-countryCode="IE" name="countrycode" value="353">Ireland (+353)</option>-->
                           <!--      <option data-countryCode="IL" name="countrycode" value="972">Israel (+972)</option>-->
                           <!--      <option data-countryCode="IT" name="countrycode" value="39">Italy (+39)</option>-->
                           <!--      <option data-countryCode="JM" name="countrycode" value="1876">Jamaica (+1876)</option>-->
                           <!--      <option data-countryCode="JP" name="countrycode" value="81">Japan (+81)</option>-->
                           <!--      <option data-countryCode="JO" name="countrycode" value="962">Jordan (+962)</option>-->
                           <!--      <option data-countryCode="KZ" name="countrycode" value="7">Kazakhstan (+7)</option>-->
                           <!--      <option data-countryCode="KE" name="countrycode" value="254">Kenya (+254)</option>-->
                           <!--      <option data-countryCode="KI" name="countrycode" value="686">Kiribati (+686)</option>-->
                           <!--      <option data-countryCode="KP" name="countrycode" value="850">Korea North (+850)</option>-->
                           <!--      <option data-countryCode="KR" name="countrycode" value="82">Korea South (+82)</option>-->
                           <!--      <option data-countryCode="KW" name="countrycode" value="965">Kuwait (+965)</option>-->
                           <!--      <option data-countryCode="KG" name="countrycode" value="996">Kyrgyzstan (+996)</option>-->
                           <!--      <option data-countryCode="LA" name="countrycode" value="856">Laos (+856)</option>-->
                           <!--      <option data-countryCode="LV" name="countrycode" value="371">Latvia (+371)</option>-->
                           <!--      <option data-countryCode="LB" name="countrycode" value="961">Lebanon (+961)</option>-->
                           <!--      <option data-countryCode="LS" name="countrycode" value="266">Lesotho (+266)</option>-->
                           <!--      <option data-countryCode="LR" name="countrycode" value="231">Liberia (+231)</option>-->
                           <!--      <option data-countryCode="LY" name="countrycode" value="218">Libya (+218)</option>-->
                           <!--      <option data-countryCode="LI" name="countrycode" value="417">Liechtenstein (+417)</option>-->
                           <!--      <option data-countryCode="LT" name="countrycode" value="370">Lithuania (+370)</option>-->
                           <!--      <option data-countryCode="LU" name="countrycode" value="352">Luxembourg (+352)</option>-->
                           <!--      <option data-countryCode="MO" name="countrycode" value="853">Macao (+853)</option>-->
                           <!--      <option data-countryCode="MK" name="countrycode" value="389">Macedonia (+389)</option>-->
                           <!--      <option data-countryCode="MG" name="countrycode" value="261">Madagascar (+261)</option>-->
                           <!--      <option data-countryCode="MW" name="countrycode" value="265">Malawi (+265)</option>-->
                           <!--      <option data-countryCode="MY" name="countrycode" value="60">Malaysia (+60)</option>-->
                           <!--      <option data-countryCode="MV" name="countrycode" value="960">Maldives (+960)</option>-->
                           <!--      <option data-countryCode="ML" name="countrycode" value="223">Mali (+223)</option>-->
                           <!--      <option data-countryCode="MT" name="countrycode" value="356">Malta (+356)</option>-->
                           <!--      <option data-countryCode="MH" name="countrycode" value="692">Marshall Islands (+692)</option>-->
                           <!--      <option data-countryCode="MQ" name="countrycode" value="596">Martinique (+596)</option>-->
                           <!--      <option data-countryCode="MR" name="countrycode" value="222">Mauritania (+222)</option>-->
                           <!--      <option data-countryCode="YT" name="countrycode" value="269">Mayotte (+269)</option>-->
                           <!--      <option data-countryCode="MX" name="countrycode" value="52">Mexico (+52)</option>-->
                           <!--      <option data-countryCode="FM" name="countrycode" value="691">Micronesia (+691)</option>-->
                           <!--      <option data-countryCode="MD" name="countrycode" value="373">Moldova (+373)</option>-->
                           <!--      <option data-countryCode="MC" name="countrycode" value="377">Monaco (+377)</option>-->
                           <!--      <option data-countryCode="MN" name="countrycode" value="976">Mongolia (+976)</option>-->
                           <!--      <option data-countryCode="MS" name="countrycode" value="1664">Montserrat (+1664)</option>-->
                           <!--      <option data-countryCode="MA" name="countrycode" value="212">Morocco (+212)</option>-->
                           <!--      <option data-countryCode="MZ" name="countrycode" value="258">Mozambique (+258)</option>-->
                           <!--      <option data-countryCode="MN" name="countrycode" value="95">Myanmar (+95)</option>-->
                           <!--      <option data-countryCode="NA" name="countrycode" value="264">Namibia (+264)</option>-->
                           <!--      <option data-countryCode="NR" name="countrycode" value="674">Nauru (+674)</option>-->
                           <!--      <option data-countryCode="NP" name="countrycode" value="977">Nepal (+977)</option>-->
                           <!--      <option data-countryCode="NL" name="countrycode" value="31">Netherlands (+31)</option>-->
                           <!--      <option data-countryCode="NC" name="countrycode" value="687">New Caledonia (+687)</option>-->
                           <!--      <option data-countryCode="NZ" name="countrycode" value="64">New Zealand (+64)</option>-->
                           <!--      <option data-countryCode="NI" name="countrycode" value="505">Nicaragua (+505)</option>-->
                           <!--      <option data-countryCode="NE" name="countrycode" value="227">Niger (+227)</option>-->
                           <!--      <option data-countryCode="NG" name="countrycode" value="234">Nigeria (+234)</option>-->
                           <!--      <option data-countryCode="NU" name="countrycode" value="683">Niue (+683)</option>-->
                           <!--      <option data-countryCode="NF" name="countrycode" value="672">Norfolk Islands (+672)</option>-->
                           <!--      <option data-countryCode="NP" name="countrycode" value="670">Northern Marianas (+670)</option>-->
                           <!--      <option data-countryCode="NO" name="countrycode" value="47">Norway (+47)</option>-->
                           <!--      <option data-countryCode="OM" name="countrycode" value="968">Oman (+968)</option>-->
                           <!--      <option data-countryCode="PW" name="countrycode" value="680">Palau (+680)</option>-->
                           <!--      <option data-countryCode="PA" name="countrycode" value="507">Panama (+507)</option>-->
                           <!--      <option data-countryCode="PG" name="countrycode" value="675">Papua New Guinea (+675)</option>-->
                           <!--      <option data-countryCode="PY" name="countrycode" value="595">Paraguay (+595)</option>-->
                           <!--      <option data-countryCode="PE" name="countrycode" value="51">Peru (+51)</option>-->
                           <!--      <option data-countryCode="PH" name="countrycode" value="63">Philippines (+63)</option>-->
                           <!--      <option data-countryCode="PL" name="countrycode" value="48">Poland (+48)</option>-->
                           <!--      <option data-countryCode="PT" name="countrycode" value="351">Portugal (+351)</option>-->
                           <!--      <option data-countryCode="PR" name="countrycode" value="1787">Puerto Rico (+1787)</option>-->
                           <!--      <option data-countryCode="QA" name="countrycode" value="974">Qatar (+974)</option>-->
                           <!--      <option data-countryCode="RE" name="countrycode" value="262">Reunion (+262)</option>-->
                           <!--      <option data-countryCode="RO" name="countrycode" value="40">Romania (+40)</option>-->
                           <!--      <option data-countryCode="RU" name="countrycode" value="7">Russia (+7)</option>-->
                           <!--      <option data-countryCode="RW" name="countrycode" value="250">Rwanda (+250)</option>-->
                           <!--      <option data-countryCode="SM" name="countrycode" value="378">San Marino (+378)</option>-->
                           <!--      <option data-countryCode="ST" name="countrycode" value="239">Sao Tome &amp; Principe (+239)</option>-->
                           <!--      <option data-countryCode="SA" name="countrycode" value="966">Saudi Arabia (+966)</option>-->
                           <!--      <option data-countryCode="SN" name="countrycode" value="221">Senegal (+221)</option>-->
                           <!--      <option data-countryCode="CS" name="countrycode" value="381">Serbia (+381)</option>-->
                           <!--      <option data-countryCode="SC" name="countrycode" value="248">Seychelles (+248)</option>-->
                           <!--      <option data-countryCode="SL" name="countrycode" value="232">Sierra Leone (+232)</option>-->
                           <!--      <option data-countryCode="SG" name="countrycode" value="65">Singapore (+65)</option>-->
                           <!--      <option data-countryCode="SK" name="countrycode" value="421">Slovak Republic (+421)</option>-->
                           <!--      <option data-countryCode="SI" name="countrycode" value="386">Slovenia (+386)</option>-->
                           <!--      <option data-countryCode="SB" name="countrycode" value="677">Solomon Islands (+677)</option>-->
                           <!--      <option data-countryCode="SO" name="countrycode" value="252">Somalia (+252)</option>-->
                           <!--      <option data-countryCode="ZA" name="countrycode" value="27">South Africa (+27)</option>-->
                           <!--      <option data-countryCode="ES" name="countrycode" value="34">Spain (+34)</option>-->
                           <!--      <option data-countryCode="LK" name="countrycode" value="94">Sri Lanka (+94)</option>-->
                           <!--      <option data-countryCode="SH" name="countrycode" value="290">St. Helena (+290)</option>-->
                           <!--      <option data-countryCode="KN" name="countrycode" value="1869">St. Kitts (+1869)</option>-->
                           <!--      <option data-countryCode="SC" name="countrycode" value="1758">St. Lucia (+1758)</option>-->
                           <!--      <option data-countryCode="SD" name="countrycode" value="249">Sudan (+249)</option>-->
                           <!--      <option data-countryCode="SR" name="countrycode" value="597">Suriname (+597)</option>-->
                           <!--      <option data-countryCode="SZ" name="countrycode" value="268">Swaziland (+268)</option>-->
                           <!--      <option data-countryCode="SE" name="countrycode" value="46">Sweden (+46)</option>-->
                           <!--      <option data-countryCode="CH" name="countrycode" value="41">Switzerland (+41)</option>-->
                           <!--      <option data-countryCode="SI" name="countrycode" value="963">Syria (+963)</option>-->
                           <!--      <option data-countryCode="TW" name="countrycode" value="886">Taiwan (+886)</option>-->
                           <!--      <option data-countryCode="TJ" name="countrycode" value="7">Tajikstan (+7)</option>-->
                           <!--      <option data-countryCode="TH" name="countrycode" value="66">Thailand (+66)</option>-->
                           <!--      <option data-countryCode="TG" name="countrycode" value="228">Togo (+228)</option>-->
                           <!--      <option data-countryCode="TO" name="countrycode" value="676">Tonga (+676)</option>-->
                           <!--      <option data-countryCode="TT" name="countrycode" value="1868">Trinidad &amp; Tobago (+1868)</option>-->
                           <!--      <option data-countryCode="TN" name="countrycode" value="216">Tunisia (+216)</option>-->
                           <!--      <option data-countryCode="TR" name="countrycode" value="90">Turkey (+90)</option>-->
                           <!--      <option data-countryCode="TM" name="countrycode" value="7">Turkmenistan (+7)</option>-->
                           <!--      <option data-countryCode="TM" name="countrycode" value="993">Turkmenistan (+993)</option>-->
                           <!--      <option data-countryCode="TC" name="countrycode" value="1649">Turks &amp; Caicos Islands (+1649)</option>-->
                           <!--      <option data-countryCode="TV" name="countrycode" value="688">Tuvalu (+688)</option>-->
                           <!--      <option data-countryCode="UG" name="countrycode" value="256">Uganda (+256)</option>-->
                                 <!-- <option data-countryCode="GB" value="44">UK (+44)</option> -->
                           <!--      <option data-countryCode="UA" name="countrycode" value="380">Ukraine (+380)</option>-->
                           <!--      <option data-countryCode="AE" name="countrycode" value="971">United Arab Emirates (+971)</option>-->
                           <!--      <option data-countryCode="UY" name="countrycode" value="598">Uruguay (+598)</option>-->
                                 <!-- <option data-countryCode="US" value="1">USA (+1)</option> -->
                           <!--      <option data-countryCode="UZ" name="countrycode" value="7">Uzbekistan (+7)</option>-->
                           <!--      <option data-countryCode="VU" name="countrycode" value="678">Vanuatu (+678)</option>-->
                           <!--      <option data-countryCode="VA" name="countrycode" value="379">Vatican City (+379)</option>-->
                           <!--      <option data-countryCode="VE" name="countrycode" value="58">Venezuela (+58)</option>-->
                           <!--      <option data-countryCode="VN" name="countrycode" value="84">Vietnam (+84)</option>-->
                           <!--      <option data-countryCode="VG" name="countrycode" value="84">Virgin Islands - British (+1284)</option>-->
                           <!--      <option data-countryCode="VI" name="countrycode" value="84">Virgin Islands - US (+1340)</option>-->
                           <!--      <option data-countryCode="WF" name="countrycode" value="681">Wallis &amp; Futuna (+681)</option>-->
                           <!--      <option data-countryCode="YE" name="countrycode" value="969">Yemen (North)(+969)</option>-->
                           <!--      <option data-countryCode="YE" name="countrycode" value="967">Yemen (South)(+967)</option>-->
                           <!--      <option data-countryCode="ZM" name="countrycode" value="260">Zambia (+260)</option>-->
                           <!--      <option data-countryCode="ZW" name="countrycode" value="263">Zimbabwe (+263)</option>-->
                           <!--   </optgroup>-->
                           <!--</select>-->
                           <input type="text" class="form-control rk-input" placeholder="Mobile" name="phone" autocomplete="off" required style='padding-left:'>
                           <div class="invalid-feedback">
                              *Please Enter Valid Number
                           </div>
                        </div>
                        <div class="col-md-12 mt-3 mb-4">
                           <input type="email" class="form-control rk-input" placeholder="Email Address" name="email" autocomplete="off" required="">
                           <div class="invalid-feedback">
                              *Please Enter Valid Email Address
                           </div>
                           <div class="form-group">
                              <br>
                              <button class="btn micro-form-btn effetGradient effectScale effetMoveGradient" name="submit" type="submit">Get Instant Call Back</button>
                           </div>
                     </form>
                  </div>
               </div>
            </div>


         </div>

         <div class="rk-modal-footer-fill">
            <a class="rk-modal-call-link" href="tel:+918879046570">
               <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 18 17.993">
                  <defs>
                     <style>
                        .a {
                           fill-rule: evenodd;
                           fill: #fff;
                        }
                     </style>
                  </defs>
                  <path class="a" d="M24.53,21.265a8.739,8.739,0,0,0-2.742,2.64c-1.284,3.377,7.523,13.346,13.168,14.9,1.589.439,2.143.244,3.452-1.212,1.852-2.06,1.751-2.5-.969-4.28-2.325-1.518-2.451-1.545-3.846-.839a7.54,7.54,0,0,1-1.143.509,50.52,50.52,0,0,1-4.575-4.514c-.13-.24-.036-.6.32-1.222.755-1.321.668-1.781-.74-3.895-1.659-2.492-1.8-2.6-2.926-2.091m6.008,1.016c0,.424.122.524.764.632a7.376,7.376,0,0,1,6.473,6.255c.125.856.2.967.647.967.492,0,.5-.028.36-1.069-.467-3.444-3.346-6.563-6.446-6.983-.485-.066-1.087-.161-1.339-.212-.377-.076-.458,0-.458.411m-3.97,1.688,1.182,1.777-.677,1.266L26.4,28.278l.845,1.095a30.927,30.927,0,0,0,4.39,4.328l.788.593,1.27-.679,1.27-.679,1.865,1.254c2.124,1.429,2.11,1.338.471,2.941l-1.011.988L35.194,37.8c-4.306-1.255-11.47-8.539-12.38-12.586l-.2-.882,1.105-1.071c1.433-1.388,1.457-1.381,2.846.706m3.97.576c0,.395.136.505.764.619a5.357,5.357,0,0,1,4.232,4.218c.119.633.224.754.654.754.917,0,.192-2.594-1.153-4.126-1.259-1.434-4.5-2.488-4.5-1.464m0,2.191c0,.408.128.544.616.651a3,3,0,0,1,2.06,1.949c.19.635.338.8.716.8.616,0,.63-.573.045-1.782-.743-1.535-3.438-2.8-3.438-1.617" transform="translate(-21.662 -21.022)" />
               </svg>
               &nbsp;+91 8879046570
            </a>
         </div>
      </div>
   </div>
   </div>


   <script type="text/javascript">
      var sitePrimaryColor = '#a88944';
   </script>
   <script src="assets/js/app-1-min.js"></script>

   <script type="text/javascript">
      $(document).ready(function() {


         if ($('.bbb_viewed_slider').length) {
            var viewedSlider = $('.bbb_viewed_slider');

            viewedSlider.owlCarousel({
               loop: true,
               margin: 30,
               autoplay: true,
               autoplayTimeout: 6000,
               nav: false,
               dots: false,
               responsive: {
                  0: {
                     items: 1
                  },
                  575: {
                     items: 2
                  },
                  768: {
                     items: 3
                  },
                  991: {
                     items: 4
                  },
                  1199: {
                     items: 5
                  }
               }
            });

            if ($('.bbb_viewed_prev').length) {
               var prev = $('.bbb_viewed_prev');
               prev.on('click', function() {
                  viewedSlider.trigger('prev.owl.carousel');
               });
            }

            if ($('.bbb_viewed_next').length) {
               var next = $('.bbb_viewed_next');
               next.on('click', function() {
                  viewedSlider.trigger('next.owl.carousel');
               });
            }
         }


      });
   </script>
</body>

</html>